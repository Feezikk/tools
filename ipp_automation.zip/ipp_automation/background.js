// background.js

// Listen for clicks on the extension icon
chrome.action.onClicked.addListener((tab) => {
    // Send a message to the content.js script on the active page.
    // This will reject if the current tab isn't ippadmin.flvs.net (no content
    // script there to receive it) or hasn't finished loading yet -- that's
    // expected, not an error, so we just swallow it quietly.
    chrome.tabs.sendMessage(tab.id, {action: "toggleUI"}).catch(() => {});
});
