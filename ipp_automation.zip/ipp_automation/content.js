// content.js

// --- 1. State Management ---
const AppState = {
    isPanelVisible: localStorage.getItem('ippUIVisible') !== 'false',
    isPanelActive: localStorage.getItem('ippUIActive') !== 'false',
    isProcessing: false,
    totalItems: 0
};

// Cache for DOM elements to avoid repeated lookups
const DOM = {};

// Table Data State
let ippRows = [];
let ippRowIdCounter = 0;

let ippUpdateRows = [];
let ippUpdateRowIdCounter = 0;

// Server-control IDs on ippadmin.flvs.net's course module detail panel.
// Centralized here since several functions across the Add/Update/Delete flows
// all read or write the same handful of fields.
const IPP_IDS = {
    grid: 'ctl04_BaseSelectionDetail1_ctl02_GridViewCourseModules',
    description: 'ctl04_BaseSelectionDetail1_ctl01_BaseTextBoxDescription',
    minutes: 'ctl04_BaseSelectionDetail1_ctl01_BaseTextBoxMinutes',
    segment: 'ctl04_BaseSelectionDetail1_ctl01_BaseTextBoxSegment',
    addButton: 'ctl04_BaseSelectionDetail1_BaseButtonAdd',
    saveAddNewButton: 'ctl04_BaseSelectionDetail1_BaseButtonSaveAddNew',
    saveButton: 'ctl04_BaseSelectionDetail1_BaseButtonSave',
    deleteButton: 'ctl04_BaseSelectionDetail1_BaseButtonDelete'
};

// Tunable delays used by the Update and Delete step machines (and the shared
// MutationObserver debounce). Lower values mean less waiting between steps,
// which can speed up a run -- but too low risks acting before the site's own
// postback has actually finished re-rendering, which just causes more retries
// and can end up net slower (or, worse, misreading a half-updated field). If
// you want to experiment with faster runs, these are the values to try
// lowering first -- start small (e.g. shave 50-100ms off at a time) and watch
// for the "select" stage's miss counter climbing or items getting skipped as
// a sign you've gone too far.
const IPP_TIMING = {
    mutationDebounceMs: 100,   // how long the DOM must be quiet before a postback is considered settled
    pollMs: 400,               // how often we recheck when waiting on a field/button that isn't ready yet
    stepSafetyTimeoutMs: 4000, // fallback in case the MutationObserver never fires for some reason
    requeueMs: 100             // delay before moving on to process the next queued item
};


// --- 2. CSS Injection ---
function injectCSS() {
    const style = document.createElement('style');
    style.textContent = `
        /* Panel Styles */
        #ippAutoPanel { position: fixed; bottom: 20px; right: 20px; background: #f8f9fa; border: 2px solid #325A7F; padding: 15px; z-index: 999999; box-shadow: 0px 4px 15px rgba(0,0,0,0.2); font-family: Arial, sans-serif; border-radius: 8px; transition: width 0.3s ease; }
        .ipp-header { display: flex; justify-content: space-between; align-items: center; transition: margin 0.3s ease; cursor: move; }
        .ipp-title { margin: 0; color: #325A7F; font-size: 16px; pointer-events: none; }
        .ipp-toggle-wrapper { display: flex; align-items: center; cursor: default; }
        .ipp-toggle-text { font-size: 12px; color: #888; font-weight: bold; }
        
        /* Toggle Switch */
        .ipp-switch { position: relative; display: inline-block; width: 36px; height: 20px; margin-left: 8px; }
        .ipp-switch input { opacity: 0; width: 0; height: 0; }
        .ipp-slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .3s; border-radius: 34px; }
        .ipp-slider:before { position: absolute; content: ""; height: 14px; width: 14px; left: 3px; bottom: 3px; background-color: white; transition: .3s; border-radius: 50%; box-shadow: 0 1px 3px rgba(0,0,0,0.3); }
        .ipp-switch input:checked + .ipp-slider { background-color: #325A7F; }
        .ipp-switch input:checked + .ipp-slider:before { transform: translateX(16px); }
        
        /* Tabs */
        .ipp-tabs { display: flex; border-bottom: 1px solid #ccc; margin-bottom: 10px; }
        .ipp-tab { flex: 1; padding: 6px 0; border: none; background: transparent; cursor: pointer; font-size: 12px; color: #555; text-align: center; transition: 0.2s; }
        .ipp-tab:hover { background: #e9ecef; }
        .ipp-tab.active { border-bottom: 2px solid #325A7F; font-weight: bold; color: #325A7F; }
        .ipp-badge { background: #dc3545; color: white; border-radius: 10px; padding: 2px 6px; font-size: 9px; margin-left: 4px; display: none; }
        
        /* Input & Preview Areas */
        .ipp-label { font-size: 11px; color: #555; margin: 0 0 8px 0; display: block; }
        .ipp-scrollable { max-height: 120px; overflow-y: auto; border: 1px solid #ccc; border-radius: 4px; padding: 0; background: #fff; margin-bottom: 10px; }
        .ipp-preview-container { text-align: center; color: #888; font-size: 11px; padding: 10px; }
        
        /* Progress & Status */
        .ipp-progress-container { width: 100%; background-color: #e9ecef; border-radius: 4px; margin-bottom: 10px; overflow: hidden; display: none; }
        .ipp-progress-bar { height: 8px; background-color: #28a745; width: 0%; transition: width 0.3s; }
        .ipp-btn { width: 100%; padding: 8px; background: #325A7F; color: white; border: none; cursor: pointer; font-weight: bold; border-radius: 4px; transition: background 0.2s; opacity: 1; }
        .ipp-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .ipp-btn.danger { background: #dc3545; }
        .ipp-status { margin-top: 10px; font-size: 12px; font-weight: bold; color: #333; text-align: center; }
        .ipp-delete-summary { font-size: 12px; color: #555; margin-bottom: 10px; text-align: center; }
        
        /* Summary Boxes */
        .ipp-summary-box { display: none; text-align: left; padding: 10px; background: #fff; border: 1px solid #ccc; border-radius: 4px; margin-top: 10px; position: relative; font-size: 12px; }
        .ipp-close-summary { position: absolute; top: 5px; right: 8px; cursor: pointer; font-size: 16px; font-weight: bold; color: #888; line-height: 1; }
        .ipp-close-summary:hover { color: #dc3545; }

        /* Editable data table (combined paste + review) */
        .ipp-edit-table { width: 100%; table-layout: fixed; border-collapse: collapse; font-size: 11px; }
        .ipp-edit-table th, .ipp-edit-table td { border-bottom: 1px solid #eee; border-right: 1px solid #eee; padding: 0; text-align: left; }
        .ipp-edit-table th { background-color: #f1f3f5; padding: 6px; position: sticky; top: 0; box-shadow: 0 1px 0 #ccc; white-space: nowrap; }
        .ipp-edit-table tr:last-child td { border-bottom: none; }
        .ipp-edit-table th:nth-child(2), .ipp-edit-table td:nth-child(2) { width: 52px; }
        .ipp-edit-table th:nth-child(3), .ipp-edit-table td:nth-child(3) { width: 52px; }
        .ipp-edit-table th:nth-child(2), .ipp-edit-table th:nth-child(3) { text-align: center; }
        .ipp-edit-table td:nth-child(2) .ipp-cell, .ipp-edit-table td:nth-child(3) .ipp-cell { padding-left: 3px; padding-right: 3px; }
        .ipp-edit-table td:last-child, .ipp-edit-table th:last-child { border-right: none; width: 45px; text-align: center; }
        .ipp-cell { width: 100%; box-sizing: border-box; border: none; background: transparent; padding: 6px; font-size: 11px; font-family: inherit; }
        .ipp-cell:focus { outline: 2px solid #325A7F; outline-offset: -2px; background: #fff; }
        .ipp-cell:disabled { color: #888; background: #f1f3f5; }
        .ipp-cell-narrow { text-align: center; }
        .ipp-row-remove { border: none; background: transparent; color: #dc3545; cursor: pointer; font-size: 14px; line-height: 1; padding: 4px 6px; }
        .ipp-row-remove:hover { color: #a71d2a; }
        .ipp-row-remove:disabled { color: #ccc; cursor: not-allowed; }
        .ipp-row-error { background-color: #ffe6e6 !important; } /* Used for duplicates AND not-found items */
        .ipp-clear-all { border: none; background: transparent; color: #dc3545; cursor: pointer; font-size: 10px; font-weight: bold; text-transform: uppercase; padding: 0; width: 100%; }
        .ipp-clear-all:hover { color: #a71d2a; }

        /* Injected grid checkboxes */
        .ipp-del-checkbox { width: 15px; height: 15px; cursor: pointer; }
        .ipp-del-th, .ipp-del-td { width: 24px; text-align: center; }
    `;
    document.head.appendChild(style);
}

// --- 3. UI Initialization ---
function createUI() {
    injectCSS();

    const panel = document.createElement('div');
    panel.id = 'ippAutoPanel'; 
    panel.style.display = AppState.isPanelVisible ? 'block' : 'none';
    panel.style.width = AppState.isPanelActive ? '30%' : '320px';

    panel.innerHTML = `
        <div id="ippHeader" class="ipp-header" style="margin-bottom: ${AppState.isPanelActive ? '10px' : '0'};">
            <h3 class="ipp-title">Magic IPP Automation</h3>
            <div class="ipp-toggle-wrapper">
                <span id="ippToggleText" class="ipp-toggle-text">${AppState.isPanelActive ? 'ON' : 'OFF'}</span>
                <label class="ipp-switch" title="Toggle Automation Panel">
                    <input type="checkbox" id="ippToggleBtn" ${AppState.isPanelActive ? 'checked' : ''}>
                    <span class="ipp-slider"></span>
                </label>
            </div>
        </div>
        
        <div id="ippBody" style="display: ${AppState.isPanelActive ? 'block' : 'none'};">
            <div class="ipp-tabs">
                <button id="ippTabData" class="ipp-tab active">1. Add Lessons</button>
                <button id="ippTabUpdate" class="ipp-tab">2. Update Lessons</button>
                <button id="ippTabDelete" class="ipp-tab">3. Delete Lessons</button>
            </div>

            <div id="ippViewData" style="display: block; margin-bottom: 10px;">
                <p class="ipp-label">Paste data (Lesson &nbsp;|&nbsp; Seg &nbsp;|&nbsp; Mins) anywhere in the table below.</p>
                <div class="ipp-scrollable">
                    <div id="ippDataTableContainer"></div>
                </div>

                <button id="ippStartBtn" class="ipp-btn" disabled>Start Automation</button>
                <div id="ippStatus" class="ipp-status">Ready</div>
                <div id="ippAddSummary" class="ipp-summary-box"></div>
            </div>

            <div id="ippViewUpdate" style="display: none; margin-bottom: 10px;">
                <p class="ipp-label">Paste updated data (Lesson &nbsp;|&nbsp; Seg &nbsp;|&nbsp; Mins) anywhere in the table below.</p>
                <div class="ipp-scrollable">
                    <div id="ippUpdateDataTableContainer"></div>
                </div>
                <div id="ippUpdateProgressContainer" class="ipp-progress-container">
                    <div id="ippUpdateProgressBar" class="ipp-progress-bar"></div>
                </div>
                <button id="ippUpdateStartBtn" class="ipp-btn" disabled>Start Updating</button>
                <div id="ippUpdateStatus" class="ipp-status">Ready</div>
                <div id="ippUpdateSummary" class="ipp-summary-box"></div>
            </div>

            <div id="ippViewDelete" style="display: none; margin-bottom: 10px;">
                <p class="ipp-label">Select the lessons to remove, then click the button to start.</p>
                <div id="ippDeleteSummary" class="ipp-delete-summary">0 selected</div>
                <div id="ippDeleteProgressContainer" class="ipp-progress-container">
                    <div id="ippDeleteProgressBar" class="ipp-progress-bar"></div>
                </div>
                <button id="ippDeleteStartBtn" class="ipp-btn danger">Delete All</button>
                <div id="ippDeleteStatus" class="ipp-status">Ready</div>
            </div>
            
            <div id="ippProgressContainer" class="ipp-progress-container">
                <div id="ippProgressBar" class="ipp-progress-bar"></div>
            </div>
        </div>
    `;

    document.body.appendChild(panel);
    cacheDOM();
    bindEvents();
    makeDraggable(panel, DOM.header);
    renderDataTable();
    renderUpdateDataTable();
}

function cacheDOM() {
    DOM.panel = document.getElementById('ippAutoPanel');
    DOM.header = document.getElementById('ippHeader');
    DOM.body = document.getElementById('ippBody');
    DOM.toggleBtn = document.getElementById('ippToggleBtn');
    DOM.toggleText = document.getElementById('ippToggleText');
    
    DOM.tabData = document.getElementById('ippTabData');
    DOM.tabUpdate = document.getElementById('ippTabUpdate');
    DOM.tabDelete = document.getElementById('ippTabDelete');
    
    DOM.viewData = document.getElementById('ippViewData');
    DOM.viewUpdate = document.getElementById('ippViewUpdate');
    DOM.viewDelete = document.getElementById('ippViewDelete');

    DOM.dataTableContainer = document.getElementById('ippDataTableContainer');
    DOM.updateDataTableContainer = document.getElementById('ippUpdateDataTableContainer');
    
    DOM.progressContainer = document.getElementById('ippProgressContainer');
    DOM.progressBar = document.getElementById('ippProgressBar');
    DOM.startBtn = document.getElementById('ippStartBtn');
    DOM.statusDiv = document.getElementById('ippStatus');
    DOM.addSummary = document.getElementById('ippAddSummary');

    DOM.updateStartBtn = document.getElementById('ippUpdateStartBtn');
    DOM.updateStatusDiv = document.getElementById('ippUpdateStatus');
    DOM.updateProgressContainer = document.getElementById('ippUpdateProgressContainer');
    DOM.updateProgressBar = document.getElementById('ippUpdateProgressBar');
    DOM.updateSummary = document.getElementById('ippUpdateSummary');

    DOM.deleteSummary = document.getElementById('ippDeleteSummary');
    DOM.deleteProgressContainer = document.getElementById('ippDeleteProgressContainer');
    DOM.deleteProgressBar = document.getElementById('ippDeleteProgressBar');
    DOM.deleteStartBtn = document.getElementById('ippDeleteStartBtn');
    DOM.deleteStatusDiv = document.getElementById('ippDeleteStatus');
}

function bindEvents() {
    DOM.startBtn.addEventListener('click', toggleAutomation);
    DOM.updateStartBtn.addEventListener('click', toggleUpdateAutomation);
    DOM.toggleBtn.addEventListener('change', handlePanelToggle);

    DOM.tabData.addEventListener('click', () => switchTab('data'));
    DOM.tabUpdate.addEventListener('click', () => switchTab('update'));
    DOM.tabDelete.addEventListener('click', () => switchTab('delete'));

    DOM.deleteStartBtn.addEventListener('click', toggleDeleteAutomation);
}

// --- 4. UI Interactions & Draggable Logic ---
function switchTab(tabName) {
    DOM.tabData.classList.toggle('active', tabName === 'data');
    DOM.tabUpdate.classList.toggle('active', tabName === 'update');
    DOM.tabDelete.classList.toggle('active', tabName === 'delete');

    DOM.viewData.style.display = tabName === 'data' ? 'block' : 'none';
    DOM.viewUpdate.style.display = tabName === 'update' ? 'block' : 'none';
    DOM.viewDelete.style.display = tabName === 'delete' ? 'block' : 'none';

    DOM.progressContainer.style.display = (tabName === 'data' && AppState.isProcessing) ? 'block' : 'none';
    DOM.statusDiv.style.display = tabName === 'data' ? 'block' : 'none';

    ippDeleteTabActive = (tabName === 'delete');
    if (ippDeleteTabActive) {
        injectDeleteCheckboxes();
    } else {
        removeDeleteCheckboxes();
    }
}

function handlePanelToggle(e) {
    const isChecked = e.target.checked;
    
    DOM.panel.style.width = isChecked ? '30%' : '320px';
    DOM.body.style.display = isChecked ? 'block' : 'none';
    DOM.header.style.marginBottom = isChecked ? '10px' : '0';
    DOM.toggleText.innerText = isChecked ? 'ON' : 'OFF';
    
    if (!isChecked) {
        DOM.panel.style.top = '';
        DOM.panel.style.left = '';
        DOM.panel.style.bottom = ''; 
        DOM.panel.style.right = '';  
    }
    
    AppState.isPanelActive = isChecked;
    localStorage.setItem('ippUIActive', isChecked);
}

function togglePanelVisibility() {
    if (!DOM.panel) return;
    const isHidden = DOM.panel.style.display === 'none';
    DOM.panel.style.display = isHidden ? 'block' : 'none';
    AppState.isPanelVisible = isHidden;
    localStorage.setItem('ippUIVisible', isHidden);
}

function makeDraggable(element, handle) {
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.onmousedown = dragMouseDown;

    function dragMouseDown(e) {
        if (e.target.closest('.ipp-switch')) return; 
        e.preventDefault();
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
        e.preventDefault();
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        
        element.style.top = (element.offsetTop - pos2) + "px";
        element.style.left = (element.offsetLeft - pos1) + "px";
        element.style.bottom = "auto"; 
        element.style.right = "auto"; 
    }

    function closeDragElement() {
        document.onmouseup = null;
        document.onmousemove = null;
    }
}

// --- 5. Data Table Utilities & Handlers ---

function createEmptyRow(id) {
    return { id: id, lesson: '', segment: '', minutes: '', isError: false };
}

function escapeAttr(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function keyForItem(item) {
    return `${item.lesson}||${item.segment}||${item.minutes}`;
}

function getLessonNumber(lessonStr) {
    return (lessonStr || '').trim().split(/\s+/)[0];
}

function normalizeSegmentMinutesOrder(row) {
    const seg = row.segment.trim();
    const min = row.minutes.trim();
    const segLooksValid = seg === '1' || seg === '2';
    const minLooksLikeSegment = min === '1' || min === '2';

    if (!segLooksValid && minLooksLikeSegment) {
        row.segment = min;
        row.minutes = seg;
    }
}

// Reusable logic for processing multi-line paste events
function handleSharedCellPaste(e, rowsArray, isUpdateTable = false) {
    const text = (e.clipboardData || window.clipboardData).getData('text');
    if (!text.includes('\t') && !text.includes('\n')) {
        return; 
    }
    e.preventDefault();

    const targetInput = e.target;
    const targetRow = targetInput.closest('tr');
    const startRowIndex = rowsArray.findIndex(r => r.id === Number(targetRow.dataset.rowId));
    const fieldOrder = ['lesson', 'segment', 'minutes'];
    const startFieldIndex = fieldOrder.indexOf(targetInput.dataset.field);

    const lines = text.split(/\r\n|\n|\r/).filter(line => line.trim() !== '');

    lines.forEach((line, lineOffset) => {
        const cols = line.split('\t');
        const rowIndex = startRowIndex + lineOffset;

        while (rowIndex >= rowsArray.length) {
            const newId = isUpdateTable ? ippUpdateRowIdCounter++ : ippRowIdCounter++;
            rowsArray.push(createEmptyRow(newId));
        }

        let touchedSegment = false;
        let touchedMinutes = false;

        cols.forEach((val, colOffset) => {
            const fieldIndex = startFieldIndex + colOffset;
            if (fieldIndex < fieldOrder.length) {
                const field = fieldOrder[fieldIndex];
                rowsArray[rowIndex][field] = val.trim();
                if (field === 'segment') touchedSegment = true;
                if (field === 'minutes') touchedMinutes = true;
            }
        });

        if (touchedSegment && touchedMinutes) {
            normalizeSegmentMinutesOrder(rowsArray[rowIndex]);
        }
    });

    if (isUpdateTable) renderUpdateDataTable();
    else renderDataTable();
}

// --- Add Table Specific Functions ---

function getParsedData() {
    const dataQueue = ippRows
        .filter(row => row.lesson.trim() !== '')
        .map(row => ({ id: row.id, lesson: row.lesson.trim(), segment: row.segment.trim(), minutes: row.minutes.trim() }));
    return { dataQueue };
}

function renderDataTable() {
    if (!DOM.dataTableContainer) return;

    if (ippRows.length === 0) ippRows.push(createEmptyRow(ippRowIdCounter++));

    let html = `<table class="ipp-edit-table"><thead><tr><th>Lesson</th><th>Seg</th><th>Mins</th><th><button type="button" class="ipp-clear-all" id="ippClearAllBtn" title="Clear all rows">Clear</button></th></tr></thead><tbody>`;
    
    ippRows.forEach(row => {
        html += `
            <tr data-row-id="${row.id}" class="${row.isError ? 'ipp-row-error' : ''}" title="${row.isError ? 'Duplicate entry skipped' : ''}">
                <td><input type="text" class="ipp-cell" data-field="lesson" value="${escapeAttr(row.lesson)}"></td>
                <td><input type="text" class="ipp-cell ipp-cell-narrow" data-field="segment" value="${escapeAttr(row.segment)}"></td>
                <td><input type="text" class="ipp-cell ipp-cell-narrow" data-field="minutes" value="${escapeAttr(row.minutes)}"></td>
                <td><button type="button" class="ipp-row-remove" title="Remove row">&times;</button></td>
            </tr>`;
    });
    html += `</tbody></table>`;
    DOM.dataTableContainer.innerHTML = html;

    DOM.dataTableContainer.querySelectorAll('.ipp-cell').forEach(input => {
        input.addEventListener('input', (e) => {
            const row = ippRows.find(r => r.id === Number(e.target.closest('tr').dataset.rowId));
            if (row) row[e.target.dataset.field] = e.target.value;
            DOM.startBtn.disabled = getParsedData().dataQueue.length === 0;
        });
        input.addEventListener('paste', (e) => handleSharedCellPaste(e, ippRows, false));
    });
    
    DOM.dataTableContainer.querySelectorAll('.ipp-row-remove').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const id = Number(e.target.closest('tr').dataset.rowId);
            ippRows = ippRows.filter(r => r.id !== id);
            renderDataTable();
        });
    });

    const clearAllBtn = DOM.dataTableContainer.querySelector('#ippClearAllBtn');
    if (clearAllBtn) {
        clearAllBtn.addEventListener('click', () => {
            if (confirm("Are you sure you want to clear all rows?")) {
                ippRows = []; 
                renderDataTable(); 
            }
        });
    }
    DOM.startBtn.disabled = getParsedData().dataQueue.length === 0;
}

function setDataTableEditable(enabled) {
    if (!DOM.dataTableContainer) return;
    DOM.dataTableContainer.querySelectorAll('.ipp-cell, .ipp-row-remove, .ipp-clear-all').forEach(el => el.disabled = !enabled);
}

// Fills a summary box with the given HTML (prefixed with a close "x" button)
// and shows it. Used by the Add and Update completion summaries.
function showSummary(container, bodyHtml) {
    if (!container) return;
    container.style.display = 'block';
    container.innerHTML = `<span class="ipp-close-summary">&times;</span>${bodyHtml}`;
    container.querySelector('.ipp-close-summary').addEventListener('click', () => {
        container.style.display = 'none';
    });
}

// --- Update Table Specific Functions ---

function getUpdateParsedData() {
    const dataQueue = ippUpdateRows
        .filter(row => row.lesson.trim() !== '')
        .map(row => ({ id: row.id, lesson: row.lesson.trim(), segment: row.segment.trim(), minutes: row.minutes.trim() }));
    return { dataQueue };
}

function renderUpdateDataTable() {
    if (!DOM.updateDataTableContainer) return;

    if (ippUpdateRows.length === 0) ippUpdateRows.push(createEmptyRow(ippUpdateRowIdCounter++));

    let html = `<table class="ipp-edit-table"><thead><tr><th>Lesson</th><th>Seg</th><th>Mins</th><th><button type="button" class="ipp-clear-all" id="ippClearAllUpdateBtn" title="Clear all rows">Clear</button></th></tr></thead><tbody>`;
    
    ippUpdateRows.forEach(row => {
        html += `
            <tr data-row-id="${row.id}" class="${row.isError ? 'ipp-row-error' : ''}" title="${row.isError ? 'Lesson not found on page' : ''}">
                <td><input type="text" class="ipp-cell" data-field="lesson" value="${escapeAttr(row.lesson)}"></td>
                <td><input type="text" class="ipp-cell ipp-cell-narrow" data-field="segment" value="${escapeAttr(row.segment)}"></td>
                <td><input type="text" class="ipp-cell ipp-cell-narrow" data-field="minutes" value="${escapeAttr(row.minutes)}"></td>
                <td><button type="button" class="ipp-row-remove" title="Remove row">&times;</button></td>
            </tr>`;
    });
    html += `</tbody></table>`;
    DOM.updateDataTableContainer.innerHTML = html;

    DOM.updateDataTableContainer.querySelectorAll('.ipp-cell').forEach(input => {
        input.addEventListener('input', (e) => {
            const row = ippUpdateRows.find(r => r.id === Number(e.target.closest('tr').dataset.rowId));
            if (row) row[e.target.dataset.field] = e.target.value;
            DOM.updateStartBtn.disabled = getUpdateParsedData().dataQueue.length === 0;
        });
        input.addEventListener('paste', (e) => handleSharedCellPaste(e, ippUpdateRows, true));
    });
    
    DOM.updateDataTableContainer.querySelectorAll('.ipp-row-remove').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const id = Number(e.target.closest('tr').dataset.rowId);
            ippUpdateRows = ippUpdateRows.filter(r => r.id !== id);
            renderUpdateDataTable();
        });
    });

    const clearAllBtn = DOM.updateDataTableContainer.querySelector('#ippClearAllUpdateBtn');
    if (clearAllBtn) {
        clearAllBtn.addEventListener('click', () => {
            if (confirm("Are you sure you want to clear all update rows?")) {
                ippUpdateRows = []; 
                renderUpdateDataTable(); 
            }
        });
    }
    DOM.updateStartBtn.disabled = getUpdateParsedData().dataQueue.length === 0;
}

function setUpdateDataTableEditable(enabled) {
    if (!DOM.updateDataTableContainer) return;
    DOM.updateDataTableContainer.querySelectorAll('.ipp-cell, .ipp-row-remove, .ipp-clear-all').forEach(el => el.disabled = !enabled);
}


// --- 6. Core Automation Logic (Add) ---

let ippAddButtonClicked = false;

function toggleAutomation() {
    if (AppState.isProcessing) {
        stopAutomation();
        return;
    }

    let { dataQueue } = getParsedData();
    
    if (dataQueue.length === 0) {
        DOM.statusDiv.innerText = "No valid data entered!";
        DOM.statusDiv.style.color = "red";
        return; 
    }

    // Duplicate lessons can exist on any grid page, so scan every page before
    // deciding what's actually new. beginAddAfterScan() picks up once that's done.
    sessionStorage.setItem('ippAddPendingQueue', JSON.stringify(dataQueue));
    sessionStorage.setItem('ippAddScanActive', 'true');
    sessionStorage.setItem('ippAddScanNextPage', '1');
    sessionStorage.setItem('ippAddScanCollected', JSON.stringify([]));

    setDataTableEditable(false);
    DOM.startBtn.disabled = true;
    if (DOM.addSummary) DOM.addSummary.style.display = 'none';
    DOM.statusDiv.innerText = "Scanning existing lessons...";
    DOM.statusDiv.style.color = "#325A7F";

    scanAllPagesStep('ippAddScan', beginAddAfterScan);
}

function beginAddAfterScan(existingRows) {
    const dataQueue = JSON.parse(sessionStorage.getItem('ippAddPendingQueue') || '[]');
    sessionStorage.removeItem('ippAddPendingQueue');

    const originalTotal = dataQueue.length;
    const existingLessonNumbers = new Set(existingRows.map(r => getLessonNumber(r.lesson)));
    const seenInPaste = new Set();
    
    let validQueue = [];
    let skippedCount = 0;
    
    ippRows.forEach(r => r.isError = false);

    dataQueue.forEach(item => {
        const lessonNum = getLessonNumber(item.lesson);
        const rowObj = ippRows.find(r => r.id === item.id);
        
        if (existingLessonNumbers.has(lessonNum) || seenInPaste.has(lessonNum)) {
            if (rowObj) rowObj.isError = true;
            skippedCount++;
        } else {
            seenInPaste.add(lessonNum);
            validQueue.push(item);
        }
    });

    renderDataTable();

    if (validQueue.length > 0) {
        AppState.isProcessing = true;
        AppState.totalItems = validQueue.length;
        
        sessionStorage.setItem('ippQueue', JSON.stringify(validQueue));
        sessionStorage.setItem('ippTotalItems', AppState.totalItems);
        sessionStorage.setItem('ippSkippedCount', skippedCount);
        sessionStorage.setItem('ippAddOriginalTotal', originalTotal);
        
        setUIForProcessing();
        processNextItem();
    } else {
        setDataTableEditable(true);
        DOM.startBtn.disabled = getParsedData().dataQueue.length === 0;

        DOM.statusDiv.innerText = `Automation Complete!`;
        DOM.statusDiv.style.color = "#28a745"; 
        
        showSummary(DOM.addSummary, `
            <strong>Summary:</strong><br/>
            Total Processed: <strong>${originalTotal}</strong><br/>
            Successfully Added: <strong style="color: #28a745;">0</strong><br/>
            Duplicates Skipped: <strong style="color: #dc3545;">${skippedCount}</strong><br/>
        `);
    }
}

function stopAutomation() {
    AppState.isProcessing = false;
    ippAddButtonClicked = false;
    DOM.startBtn.innerText = "Start Automation";
    DOM.startBtn.style.background = "#325A7F";
    DOM.statusDiv.innerText = "Automation Stopped.";
    DOM.statusDiv.style.color = "#dc3545";
    setDataTableEditable(true);
    sessionStorage.removeItem('ippQueue');
}

function setUIForProcessing() {
    DOM.startBtn.innerText = "Stop / Cancel";
    DOM.startBtn.style.background = "#dc3545";
    setDataTableEditable(false);
    
    if (DOM.addSummary) DOM.addSummary.style.display = 'none';
    DOM.progressContainer.style.display = 'block';
    DOM.progressBar.style.width = '0%';
    
    switchTab('data');
}

function processNextItem() {
    if (!AppState.isProcessing) return; 

    let queue = JSON.parse(sessionStorage.getItem('ippQueue') || '[]');
    let initialTotal = parseInt(sessionStorage.getItem('ippTotalItems') || queue.length);

    if (queue.length === 0) {
        finishAutomation();
        return;
    }

    const completed = initialTotal - queue.length;
    DOM.progressBar.style.width = `${Math.round((completed / initialTotal) * 100)}%`;

    DOM.statusDiv.innerText = `Processing... (${queue.length} items left)`;
    DOM.statusDiv.style.color = "#325A7F";
    
    const currentItem = queue[0];
    const targetFields = {
        desc: document.getElementById(IPP_IDS.description),
        min: document.getElementById(IPP_IDS.minutes),
        seg: document.getElementById(IPP_IDS.segment),
        btn: document.getElementById(IPP_IDS.saveAddNewButton)
    };

    if (targetFields.desc && !targetFields.desc.disabled && targetFields.btn && !targetFields.btn.disabled) {
        ippAddButtonClicked = false;
        targetFields.desc.value = currentItem.lesson;
        targetFields.min.value = currentItem.minutes;
        targetFields.seg.value = currentItem.segment;

        queue.shift(); 
        sessionStorage.setItem('ippQueue', JSON.stringify(queue));

        targetFields.btn.click();
        waitForReset();
    } else {
        const addBtn = document.getElementById(IPP_IDS.addButton);
        if (addBtn && !addBtn.disabled && !ippAddButtonClicked) {
            ippAddButtonClicked = true;
            DOM.statusDiv.innerText = "Opening the Add form...";
            DOM.statusDiv.style.color = "#325A7F";
            addBtn.click();
            setTimeout(() => { ippAddButtonClicked = false; }, 5000);
        } else if (!addBtn) {
            DOM.statusDiv.innerText = "Select 'Add' to begin automation...";
            DOM.statusDiv.style.color = "#c71585";
        }
        setTimeout(processNextItem, 1000); 
    }
}

function finishAutomation() {
    const skippedCount = parseInt(sessionStorage.getItem('ippSkippedCount') || '0');
    const originalTotal = parseInt(sessionStorage.getItem('ippAddOriginalTotal') || '0');
    const successCount = originalTotal - skippedCount;
    
    if (DOM.statusDiv) {
        DOM.statusDiv.innerText = "Automation Complete!";
        DOM.statusDiv.style.color = "#28a745";
    }

    let addSummaryHtml = `<strong>Summary:</strong><br/>`;
    addSummaryHtml += `Total Processed: <strong>${originalTotal}</strong><br/>`;
    addSummaryHtml += `Successfully Added: <strong style="color: #28a745;">${successCount}</strong><br/>`;

    if (skippedCount > 0) {
        addSummaryHtml += `Duplicates Skipped: <strong style="color: #dc3545;">${skippedCount}</strong><br/>`;
    } else {
        addSummaryHtml += `<span style="color: #28a745;">All items added successfully!</span>`;
    }
    showSummary(DOM.addSummary, addSummaryHtml);
    
    ippRows = ippRows.filter(row => row.isError || row.lesson.trim() === '');
    
    setDataTableEditable(true);
    
    DOM.startBtn.innerText = "Start Automation";
    DOM.startBtn.style.background = "#325A7F";
    AppState.isProcessing = false;
    ippAddButtonClicked = false;
    
    sessionStorage.removeItem('ippQueue');
    sessionStorage.removeItem('ippTotalItems');
    sessionStorage.removeItem('ippSkippedCount');
    sessionStorage.removeItem('ippAddOriginalTotal');
    
    DOM.progressBar.style.width = '100%';
    renderDataTable();
}

function waitForReset() {
    if (!AppState.isProcessing) return;
    
    setTimeout(() => {
        const descField = document.getElementById(IPP_IDS.description);
        if (descField && !descField.disabled && descField.value === '') {
            processNextItem();
        } else {
            waitForReset();
        }
    }, 500);
}


// --- 7. Core Automation Logic (Update) ---

let ippUpdateStepInFlight = false;

// Clears all sessionStorage keys tracking an in-progress (or just-finished)
// Update run. Shared by stopUpdateAutomation() and finishUpdateAutomation(),
// which otherwise need the exact same cleanup.
function clearUpdateQueueState() {
    sessionStorage.removeItem('ippUpdateQueue');
    sessionStorage.removeItem('ippUpdateTotal');
    sessionStorage.removeItem('ippUpdateStage');
    sessionStorage.removeItem('ippUpdateActive');
    sessionStorage.removeItem('ippUpdateTargetOldName');
    sessionStorage.removeItem('ippUpdateNotFound');
    sessionStorage.removeItem('ippUpdateNotFoundIds');
    sessionStorage.removeItem('ippUpdateSuccess');
    sessionStorage.removeItem('ippUpdateSearchPage');
}

function toggleUpdateAutomation() {
    if (sessionStorage.getItem('ippUpdateActive') === 'true') {
        stopUpdateAutomation();
        return;
    }
    startUpdateAutomation();
}

function startUpdateAutomation() {
    const { dataQueue } = getUpdateParsedData();

    if (dataQueue.length === 0) {
        DOM.updateStatusDiv.innerText = "No data entered!";
        DOM.updateStatusDiv.style.color = "red";
        return;
    }
    
    ippUpdateRows.forEach(r => r.isError = false);
    renderUpdateDataTable();

    sessionStorage.setItem('ippUpdateQueue', JSON.stringify(dataQueue));
    sessionStorage.setItem('ippUpdateTotal', dataQueue.length);
    sessionStorage.setItem('ippUpdateStage', 'find');
    sessionStorage.setItem('ippUpdateActive', 'true');
    sessionStorage.setItem('ippUpdateNotFound', JSON.stringify([]));
    sessionStorage.setItem('ippUpdateNotFoundIds', JSON.stringify([])); 
    sessionStorage.setItem('ippUpdateSuccess', '0');
    sessionStorage.removeItem('ippUpdateSearchPage');

    setUIForUpdateProcessing();
    runUpdateStep();
}

function stopUpdateAutomation() {
    clearUpdateQueueState();
    ippUpdateStepInFlight = false;

    DOM.updateStartBtn.innerText = "Start Updating";
    DOM.updateStartBtn.style.background = "#325A7F";
    DOM.updateStatusDiv.innerText = "Update Stopped.";
    DOM.updateStatusDiv.style.color = "#dc3545";
    setUpdateDataTableEditable(true);
}

function setUIForUpdateProcessing() {
    DOM.updateStartBtn.disabled = false;
    DOM.updateStartBtn.innerText = "Stop / Cancel";
    DOM.updateStartBtn.style.background = "#dc3545";
    setUpdateDataTableEditable(false);
    
    if (DOM.updateSummary) DOM.updateSummary.style.display = 'none';
    DOM.updateProgressContainer.style.display = 'block';
    DOM.updateProgressBar.style.width = '0%';
    DOM.updateStatusDiv.innerText = 'Updating...';
    DOM.updateStatusDiv.style.color = '#325A7F';
}

function runUpdateStep() {
    if (sessionStorage.getItem('ippUpdateActive') !== 'true') return;
    if (ippUpdateStepInFlight) return;

    const queue = JSON.parse(sessionStorage.getItem('ippUpdateQueue') || '[]');
    const total = parseInt(sessionStorage.getItem('ippUpdateTotal') || queue.length);
    const stage = sessionStorage.getItem('ippUpdateStage') || 'find';
    const notFound = JSON.parse(sessionStorage.getItem('ippUpdateNotFound') || '[]');
    const notFoundIds = JSON.parse(sessionStorage.getItem('ippUpdateNotFoundIds') || '[]');
    let successCount = parseInt(sessionStorage.getItem('ippUpdateSuccess') || '0');

    if (DOM.updateStatusDiv) {
        const completed = total - queue.length;
        DOM.updateProgressBar.style.width = `${Math.round((completed / total) * 100)}%`;
        DOM.updateStatusDiv.innerText = queue.length > 0 ? `Updating... (${queue.length} left)` : 'Updating...';
    }

    if (queue.length === 0) {
        finishUpdateAutomation(total, successCount, notFound);
        return;
    }

    const target = queue[0];
    const targetLessonNumber = getLessonNumber(target.lesson);

    if (stage === 'find') {
        // Which page we're currently checking for THIS item (persists across
        // postbacks so we don't lose our place, and resets to 1 once this item
        // is found or exhausted so the next item starts fresh).
        const searchPage = parseInt(sessionStorage.getItem('ippUpdateSearchPage') || '1', 10);
        const pager = getPagerInfo();

        if (goToSearchPageIfNeeded(pager, searchPage, v => { ippUpdateStepInFlight = v; })) return;

        const { currentPage, pageLinks } = pager;
        const rows = getGridRows();
        const match = rows.find(r => getLessonNumber(r.lesson) === targetLessonNumber);

        if (match) {
            sessionStorage.removeItem('ippUpdateSearchPage');
            ippUpdateStepInFlight = true;
            sessionStorage.setItem('ippUpdateTargetOldName', match.lesson);
            sessionStorage.setItem('ippUpdateStage', 'edit');
            match.row.click();
            
            setTimeout(() => { ippUpdateStepInFlight = false; }, IPP_TIMING.stepSafetyTimeoutMs);
            return;
        }

        if (pageLinks[currentPage + 1]) {
            sessionStorage.setItem('ippUpdateSearchPage', (currentPage + 1).toString());
            ippUpdateStepInFlight = true;
            goToGridPage(currentPage + 1);
            setTimeout(() => { ippUpdateStepInFlight = false; }, IPP_TIMING.stepSafetyTimeoutMs);
            return;
        }

        // Not found on any page.
        sessionStorage.removeItem('ippUpdateSearchPage');
        notFound.push(targetLessonNumber);
        notFoundIds.push(target.id); 
        
        sessionStorage.setItem('ippUpdateNotFound', JSON.stringify(notFound));
        sessionStorage.setItem('ippUpdateNotFoundIds', JSON.stringify(notFoundIds));
        
        queue.shift();
        sessionStorage.setItem('ippUpdateQueue', JSON.stringify(queue));
        setTimeout(runUpdateStep, IPP_TIMING.requeueMs);
        return;
    }

    if (stage === 'edit') {
        const saveBtn = document.getElementById(IPP_IDS.saveButton) || document.getElementById(IPP_IDS.saveAddNewButton);
        const descField = document.getElementById(IPP_IDS.description);
        const minField = document.getElementById(IPP_IDS.minutes);
        const segField = document.getElementById(IPP_IDS.segment);
        const oldName = sessionStorage.getItem('ippUpdateTargetOldName');

        if (!saveBtn || !descField || descField.disabled) {
            setTimeout(runUpdateStep, IPP_TIMING.pollMs);
            return;
        }

        if (descField.value.trim() !== oldName) {
            setTimeout(runUpdateStep, IPP_TIMING.pollMs);
            return;
        }

        descField.value = target.lesson;
        if (target.minutes) minField.value = target.minutes;
        if (target.segment) segField.value = target.segment;

        successCount++;
        sessionStorage.setItem('ippUpdateSuccess', successCount.toString());
        
        queue.shift();
        sessionStorage.setItem('ippUpdateQueue', JSON.stringify(queue));
        sessionStorage.setItem('ippUpdateStage', 'find');

        ippUpdateStepInFlight = true;
        saveBtn.click(); 
        
        setTimeout(() => { ippUpdateStepInFlight = false; }, IPP_TIMING.stepSafetyTimeoutMs);
        return;
    }
}

function finishUpdateAutomation(total, successCount, notFound) {
    const notFoundIds = JSON.parse(sessionStorage.getItem('ippUpdateNotFoundIds') || '[]');

    clearUpdateQueueState();

    if (DOM.updateStatusDiv) {
        DOM.updateStatusDiv.innerText = `Update Complete!`;
        DOM.updateStatusDiv.style.color = '#28a745';
    }
    if (DOM.updateProgressBar) {
        DOM.updateProgressBar.style.width = '100%';
    }
    if (DOM.updateStartBtn) {
        DOM.updateStartBtn.disabled = false;
        DOM.updateStartBtn.innerText = "Start Updating";
        DOM.updateStartBtn.style.background = "#325A7F";
    }
    
    ippUpdateRows.forEach(row => {
        if (notFoundIds.includes(row.id)) {
            row.isError = true;
        }
    });
    ippUpdateRows = ippUpdateRows.filter(row => row.isError || row.lesson.trim() === '');
    
    setUpdateDataTableEditable(true);
    renderUpdateDataTable();
    
    let updateSummaryHtml = `<strong>Summary:</strong><br/>`;
    updateSummaryHtml += `Total Processed: <strong>${total}</strong><br/>`;
    updateSummaryHtml += `Successfully Updated: <strong style="color: #28a745;">${successCount}</strong><br/><br/>`;

    if (notFound.length > 0) {
        updateSummaryHtml += `<span style="color: #dc3545;"><strong>Not Found (${notFound.length}):</strong><br/>${notFound.join(', ')}</span>`;
    } else {
        updateSummaryHtml += `<span style="color: #28a745;">All items found and updated successfully!</span>`;
    }
    showSummary(DOM.updateSummary, updateSummaryHtml);
}


// --- 8. Grid Checkbox Injection & Delete Automation ---

let ippDeleteTabActive = false;
let ippSelectedForDelete = new Set();
let ippLastCheckedItemKey = null; // last individually-clicked checkbox, for shift-click range selection

// Adds/removes a grid row from the delete selection and keeps its checkbox
// (if rendered) in sync. Shared by the select-all checkbox, shift-click range
// selection, and a single checkbox's own change handler, since all three
// boil down to "mark this row selected or not."
function setItemSelected(item, selected) {
    const key = keyForItem(item);
    if (selected) {
        ippSelectedForDelete.add(key);
    } else {
        ippSelectedForDelete.delete(key);
    }
    const rowCb = item.row.querySelector('.ipp-del-checkbox:not(.ipp-del-select-all)');
    if (rowCb) rowCb.checked = selected;
}

function getGridRows() {
    const table = document.getElementById(IPP_IDS.grid);
    if (!table) return [];

    const rows = Array.from(table.querySelectorAll('tr')).filter(r => r.hasAttribute('onclick'));

    return rows.map(row => {
        const cells = row.querySelectorAll('td');
        const offset = row.querySelector('.ipp-del-td') ? 1 : 0;
        return {
            row,
            lesson: cells[offset] ? cells[offset].textContent.trim() : '',
            segment: cells[offset + 1] ? cells[offset + 1].textContent.trim() : '',
            minutes: cells[offset + 2] ? cells[offset + 2].textContent.trim() : ''
        };
    });
}

// --- 8b. Multi-Page Grid Navigation ---
// IPP shows up to 50 lessons per grid page; larger courses spill onto page 2, 3, etc.
// The pager lives in a <tr class="GridView_PagerStyleClass"> row inside the same
// table, with the current page rendered as a plain <span> and every other page as
// an <a href="javascript:__doPostBack(...)">. Paging is an ASP.NET AJAX UpdatePanel
// postback (see Sys.WebForms.PageRequestManager on the page), so the grid updates
// in place -- our existing MutationObserver-driven handleDomSettled() picks up the
// change just like it already does after an Add/Update/Delete action.

function getPagerInfo() {
    const table = document.getElementById(IPP_IDS.grid);
    const info = { currentPage: 1, pageLinks: {} };
    if (!table) return info;

    const pagerRow = table.querySelector('tr.GridView_PagerStyleClass');
    if (!pagerRow) return info; // only one page -- nothing to page through

    pagerRow.querySelectorAll('td').forEach(td => {
        const span = td.querySelector('span');
        if (span && /^\d+$/.test(span.textContent.trim())) {
            info.currentPage = parseInt(span.textContent.trim(), 10);
        }
        const link = td.querySelector('a');
        if (link) {
            const pageNum = parseInt(link.textContent.trim(), 10);
            if (!isNaN(pageNum)) info.pageLinks[pageNum] = link;
        }
    });

    return info;
}

function goToGridPage(pageNum) {
    const { pageLinks } = getPagerInfo();
    const link = pageLinks[pageNum];
    if (!link) return false;

    // The pager's href is "javascript:__doPostBack('target','arg')". Navigating
    // that directly (e.g. link.click()) is blocked by this site's CSP, so we
    // parse the target/argument out of the href ourselves -- just reading the
    // attribute, no execution -- and hand them to the MAIN-world bridge script
    // (postback-bridge.js) to actually call __doPostBack.
    const href = link.getAttribute('href') || '';
    const parsed = href.match(/__doPostBack\(\s*'([^']*)'\s*,\s*'([^']*)'\s*\)/);
    if (!parsed) return false;

    window.dispatchEvent(new CustomEvent('ippDoPostBack', {
        detail: { target: parsed[1], argument: parsed[2] }
    }));
    return true;
}

// Shared by the Update-find and Delete-select step machines below: both walk
// the grid page-by-page looking for a specific lesson, tracking "which page
// are we checking right now" in sessionStorage so they don't lose their place
// across postbacks. This just handles "are we on that page yet" -- if not, it
// kicks off the navigation and returns true so the caller can bail out early;
// if we're already there, it returns false so the caller can check for a match.
function goToSearchPageIfNeeded(pagerInfo, targetPage, setInFlight) {
    if (pagerInfo.currentPage === targetPage) return false;
    setInFlight(true);
    goToGridPage(targetPage);
    setTimeout(() => setInFlight(false), IPP_TIMING.stepSafetyTimeoutMs);
    return true;
}

function itemFromKey(key) {
    const [lesson, segment, minutes] = key.split('||');
    return { lesson, segment, minutes };
}

// Generic helper that walks every page of the grid, collecting each page's rows,
// then hands the combined list to onDone(). Progress lives in sessionStorage
// (keyed by `prefix`) purely so an in-progress scan can pick back up via
// handleDomSettled() or the auto-resume block at the bottom of this file --
// normal pagination never actually reloads the page.
let ippScanStepInFlight = {};

function scanAllPagesStep(prefix, onDone) {
    if (sessionStorage.getItem(prefix + 'Active') !== 'true') return;
    if (ippScanStepInFlight[prefix]) return;

    const nextPageToScan = parseInt(sessionStorage.getItem(prefix + 'NextPage') || '1', 10);
    const { currentPage, pageLinks } = getPagerInfo();

    if (currentPage !== nextPageToScan) {
        const clicked = goToGridPage(nextPageToScan);
        if (clicked) {
            ippScanStepInFlight[prefix] = true;
            setTimeout(() => { ippScanStepInFlight[prefix] = false; }, IPP_TIMING.stepSafetyTimeoutMs);
        }
        return;
    }

    const collected = JSON.parse(sessionStorage.getItem(prefix + 'Collected') || '[]');
    collected.push(...getGridRows().map(r => ({ lesson: r.lesson, segment: r.segment, minutes: r.minutes })));

    if (pageLinks[currentPage + 1]) {
        sessionStorage.setItem(prefix + 'Collected', JSON.stringify(collected));
        sessionStorage.setItem(prefix + 'NextPage', (currentPage + 1).toString());
        ippScanStepInFlight[prefix] = true;
        goToGridPage(currentPage + 1);
        setTimeout(() => { ippScanStepInFlight[prefix] = false; }, IPP_TIMING.stepSafetyTimeoutMs);
        return;
    }

    sessionStorage.removeItem(prefix + 'Active');
    sessionStorage.removeItem(prefix + 'NextPage');
    sessionStorage.removeItem(prefix + 'Collected');
    onDone(collected);
}

function injectDeleteCheckboxes() {
    if (!ippDeleteTabActive) return;

    const table = document.getElementById(IPP_IDS.grid);
    if (!table || table.dataset.ippCheckboxesInjected) return;
    table.dataset.ippCheckboxesInjected = 'true';

    const headerRow = table.querySelector('tr.GridView_HeaderStyleClass');
    if (headerRow) {
        const th = document.createElement('th');
        th.className = 'ipp-del-th';
        th.scope = 'col';

        const selectAllCb = document.createElement('input');
        selectAllCb.type = 'checkbox';
        selectAllCb.className = 'ipp-del-checkbox ipp-del-select-all';
        selectAllCb.title = 'Select/deselect all';
        selectAllCb.addEventListener('click', (e) => e.stopPropagation());
        selectAllCb.addEventListener('change', (e) => {
            const shouldSelect = e.target.checked;
            getGridRows().forEach(item => setItemSelected(item, shouldSelect));
            updateDeleteSelectionCount();
        });

        th.appendChild(selectAllCb);
        headerRow.insertBefore(th, headerRow.firstChild);
    }

    getGridRows().forEach(item => {
        const td = document.createElement('td');
        td.className = 'ipp-del-td';

        const cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.className = 'ipp-del-checkbox';
        cb.checked = ippSelectedForDelete.has(keyForItem(item));
        cb.addEventListener('click', (e) => {
            e.stopPropagation();

            // Shift-click selects/deselects everything between this row and
            // the last row that was individually clicked (a classic "shift
            // to select a range" pattern). By the time a checkbox's own click
            // handler runs, .checked already reflects the new post-toggle
            // state, so that's the state we apply across the whole range.
            if (e.shiftKey && ippLastCheckedItemKey) {
                const rows = getGridRows();
                const currentIndex = rows.findIndex(r => keyForItem(r) === keyForItem(item));
                const lastIndex = rows.findIndex(r => keyForItem(r) === ippLastCheckedItemKey);

                if (currentIndex !== -1 && lastIndex !== -1) {
                    const shouldSelect = cb.checked;
                    const [start, end] = lastIndex < currentIndex ? [lastIndex, currentIndex] : [currentIndex, lastIndex];

                    for (let i = start; i <= end; i++) {
                        setItemSelected(rows[i], shouldSelect);
                    }
                    updateDeleteSelectionCount();
                }
            }

            ippLastCheckedItemKey = keyForItem(item);
        });
        cb.addEventListener('change', (e) => {
            setItemSelected(item, e.target.checked);
            updateDeleteSelectionCount();
        });

        td.appendChild(cb);
        item.row.insertBefore(td, item.row.firstChild);
    });

    updateDeleteSelectionCount();
}

function updateSelectAllCheckboxState() {
    const selectAllCb = document.querySelector('.ipp-del-select-all');
    if (!selectAllCb) return;

    const rows = getGridRows();
    if (rows.length === 0) {
        selectAllCb.checked = false;
        selectAllCb.indeterminate = false;
        return;
    }

    const selectedCount = rows.filter(item => ippSelectedForDelete.has(keyForItem(item))).length;
    selectAllCb.checked = selectedCount === rows.length;
    selectAllCb.indeterminate = selectedCount > 0 && selectedCount < rows.length;
}

function removeDeleteCheckboxes() {
    const table = document.getElementById(IPP_IDS.grid);
    if (!table) return;
    table.querySelectorAll('.ipp-del-th, .ipp-del-td').forEach(el => el.remove());
    delete table.dataset.ippCheckboxesInjected;
    ippLastCheckedItemKey = null;
}

function updateDeleteSelectionCount() {
    const count = ippSelectedForDelete.size;
    if (DOM.deleteSummary) {
        DOM.deleteSummary.textContent = `${count} selected`;
    }
    if (DOM.deleteStartBtn) {
        const totalRows = getGridRows().length;
        
        if (totalRows === 0) {
            DOM.deleteStartBtn.disabled = true;
            DOM.deleteStartBtn.innerText = "Delete All";
        } else if (count === 0) {
            DOM.deleteStartBtn.disabled = false;
            DOM.deleteStartBtn.innerText = "Delete All";
        } else {
            DOM.deleteStartBtn.disabled = false;
            DOM.deleteStartBtn.innerText = "Delete Selected";
        }
    }
    updateSelectAllCheckboxState();
}

function toggleDeleteAutomation() {
    const busy = sessionStorage.getItem('ippDeleteActive') === 'true' ||
        sessionStorage.getItem('ippDeleteAllScanActive') === 'true';

    if (busy) {
        stopDeleteAutomation();
        return;
    }
    startDeleteAutomation();
}

function startDeleteAutomation() {
    if (ippSelectedForDelete.size > 0) {
        // Selections are tracked by key (lesson||segment||minutes), which already
        // survives switching between grid pages, so the delete queue can be built
        // straight from those keys without needing every page's rows on hand.
        const targets = Array.from(ippSelectedForDelete).map(itemFromKey);
        beginDeleteWithTargets(targets);
        return;
    }

    if (!confirm("Are you sure you want to delete ALL lessons on every page?")) return;

    setUIForDeleteScanning();
    sessionStorage.setItem('ippDeleteAllScanActive', 'true');
    sessionStorage.setItem('ippDeleteAllScanNextPage', '1');
    sessionStorage.setItem('ippDeleteAllScanCollected', JSON.stringify([]));
    scanAllPagesStep('ippDeleteAllScan', beginDeleteWithTargets);
}

// Clears all sessionStorage keys tracking an in-progress (or just-finished)
// Delete run. Shared by stopDeleteAutomation() and finishDeleteAutomation(),
// which otherwise need the exact same cleanup.
function clearDeleteQueueState() {
    sessionStorage.removeItem('ippDeleteQueue');
    sessionStorage.removeItem('ippDeleteTotal');
    sessionStorage.removeItem('ippDeleteStage');
    sessionStorage.removeItem('ippDeleteActive');
    sessionStorage.removeItem('ippDeleteSearchPage');
    sessionStorage.removeItem('ippDeleteSelectMisses');
}

function stopDeleteAutomation() {
    clearDeleteQueueState();

    sessionStorage.removeItem('ippDeleteAllScanActive');
    sessionStorage.removeItem('ippDeleteAllScanNextPage');
    sessionStorage.removeItem('ippDeleteAllScanCollected');

    ippDeleteStepInFlight = false;
    ippScanStepInFlight['ippDeleteAllScan'] = false;

    DOM.deleteStatusDiv.innerText = 'Deletion Stopped.';
    DOM.deleteStatusDiv.style.color = '#dc3545';

    injectDeleteCheckboxes();
    updateDeleteSelectionCount();
}

function setUIForDeleteScanning() {
    DOM.deleteStartBtn.disabled = false;
    DOM.deleteStartBtn.innerText = 'Stop / Cancel';
    DOM.deleteStatusDiv.innerText = 'Scanning all pages...';
    DOM.deleteStatusDiv.style.color = '#325A7F';
}

function beginDeleteWithTargets(targets) {
    if (targets.length === 0) {
        injectDeleteCheckboxes();
        updateDeleteSelectionCount();
        return;
    }

    targets.forEach(t => ippSelectedForDelete.delete(keyForItem(t)));
    updateDeleteSelectionCount();

    sessionStorage.setItem('ippDeleteQueue', JSON.stringify(targets));
    sessionStorage.setItem('ippDeleteTotal', targets.length);
    sessionStorage.setItem('ippDeleteStage', 'select');
    sessionStorage.setItem('ippDeleteActive', 'true');
    sessionStorage.removeItem('ippDeleteSearchPage');
    sessionStorage.removeItem('ippDeleteSelectMisses');

    setUIForDeleteProcessing();
    runDeleteStep();
}

function setUIForDeleteProcessing() {
    DOM.deleteStartBtn.disabled = false;
    DOM.deleteStartBtn.innerText = 'Stop / Cancel';
    DOM.deleteProgressContainer.style.display = 'block';
    DOM.deleteProgressBar.style.width = '0%';
    DOM.deleteStatusDiv.innerText = 'Deleting...';
    DOM.deleteStatusDiv.style.color = '#325A7F';
}

let ippDeleteStepInFlight = false;

function runDeleteStep() {
    if (sessionStorage.getItem('ippDeleteActive') !== 'true') return;
    if (ippDeleteStepInFlight) return;

    const queue = JSON.parse(sessionStorage.getItem('ippDeleteQueue') || '[]');
    const total = parseInt(sessionStorage.getItem('ippDeleteTotal') || queue.length);
    const stage = sessionStorage.getItem('ippDeleteStage') || 'select';

    if (DOM.deleteStatusDiv) {
        const completed = total - queue.length;
        DOM.deleteProgressBar.style.width = `${Math.round((completed / total) * 100)}%`;
        DOM.deleteStatusDiv.innerText = queue.length > 0 ? `Deleting... (${queue.length} left)` : 'Deleting...';
    }

    if (queue.length === 0) {
        finishDeleteAutomation();
        return;
    }

    const target = queue[0];

    if (stage === 'select') {
        // Which page we're currently checking for THIS item (persists across
        // postbacks so we don't lose our place). We still restart each new
        // item's search at page 1 -- see beginDeleteWithTargets/confirmDelete
        // below -- since earlier deletions can shift later lessons onto
        // earlier pages, so starting from the top each time is the only way
        // to be sure none get skipped.
        const searchPage = parseInt(sessionStorage.getItem('ippDeleteSearchPage') || '1', 10);
        const pager = getPagerInfo();

        if (pager.currentPage !== searchPage) {
            sessionStorage.setItem('ippDeleteSelectMisses', '0');
        }
        if (goToSearchPageIfNeeded(pager, searchPage, v => { ippDeleteStepInFlight = v; })) return;

        const { currentPage, pageLinks } = pager;
        const rows = getGridRows();
        const match = rows.find(r => r.lesson === target.lesson && r.segment === target.segment && r.minutes === target.minutes);

        if (match) {
            ippDeleteStepInFlight = true;
            sessionStorage.setItem('ippDeleteStage', 'confirmDelete');
            sessionStorage.removeItem('ippDeleteSelectMisses');
            sessionStorage.removeItem('ippDeleteSearchPage');
            match.row.click();
            setTimeout(() => { ippDeleteStepInFlight = false; }, IPP_TIMING.stepSafetyTimeoutMs);
            return;
        }

        // Give the current page a few chances to settle -- e.g. right after a
        // prior delete the grid may still be re-rendering -- before concluding
        // the item genuinely isn't on this page.
        const misses = parseInt(sessionStorage.getItem('ippDeleteSelectMisses') || '0', 10);
        if (misses < 5) {
            sessionStorage.setItem('ippDeleteSelectMisses', (misses + 1).toString());
            setTimeout(runDeleteStep, IPP_TIMING.pollMs);
            return;
        }

        if (pageLinks[currentPage + 1]) {
            sessionStorage.setItem('ippDeleteSearchPage', (currentPage + 1).toString());
            sessionStorage.setItem('ippDeleteSelectMisses', '0');
            ippDeleteStepInFlight = true;
            goToGridPage(currentPage + 1);
            setTimeout(() => { ippDeleteStepInFlight = false; }, IPP_TIMING.stepSafetyTimeoutMs);
            return;
        }

        // Exhausted every page -- this item is already gone (or never existed).
        // Skip it rather than retrying forever.
        sessionStorage.removeItem('ippDeleteSelectMisses');
        sessionStorage.removeItem('ippDeleteSearchPage');
        queue.shift();
        sessionStorage.setItem('ippDeleteQueue', JSON.stringify(queue));
        setTimeout(runDeleteStep, IPP_TIMING.requeueMs);
        return;
    }

    if (stage === 'confirmDelete') {
        const deleteBtn = document.getElementById(IPP_IDS.deleteButton);
        const descField = document.getElementById(IPP_IDS.description);

        if (!deleteBtn || !descField) {
            setTimeout(runDeleteStep, IPP_TIMING.pollMs);
            return;
        }

        if (descField.value.trim() !== target.lesson) {
            setTimeout(runDeleteStep, IPP_TIMING.pollMs);
            return;
        }

        queue.shift();
        sessionStorage.setItem('ippDeleteQueue', JSON.stringify(queue));
        sessionStorage.setItem('ippDeleteStage', 'select');

        ippDeleteStepInFlight = true;
        deleteBtn.click(); 

        setTimeout(() => { ippDeleteStepInFlight = false; }, IPP_TIMING.stepSafetyTimeoutMs);
        return;
    }
}

// --- 9. DOM Watcher ---
let ippObserver = null;
let ippMutationDebounce = null;

function handleDomSettled() {
    if (ippObserver) ippObserver.disconnect();

    // The delete checkboxes are only there for manual selection -- the delete
    // automation itself drives everything off getGridRows()/row.click() and
    // never looks at them. Each step of that automation (a page navigation, a
    // delete confirmation, etc.) triggers a postback that swaps in a fresh
    // grid table without checkboxes, so re-adding them here on every settle
    // just made them flash in and out for no reason. Skip it while busy, and
    // let finishDeleteAutomation()/beginDeleteWithTargets() restore them once
    // there's nothing left running.
    const deleteBusy = sessionStorage.getItem('ippDeleteActive') === 'true' ||
        sessionStorage.getItem('ippDeleteAllScanActive') === 'true';

    if (!deleteBusy) {
        injectDeleteCheckboxes();
        updateDeleteSelectionCount();
    }

    if (sessionStorage.getItem('ippDeleteActive') === 'true') {
        ippDeleteStepInFlight = false;
        runDeleteStep();
    }
    
    if (sessionStorage.getItem('ippUpdateActive') === 'true') {
        ippUpdateStepInFlight = false;
        runUpdateStep();
    }

    if (sessionStorage.getItem('ippAddScanActive') === 'true') {
        ippScanStepInFlight['ippAddScan'] = false;
        scanAllPagesStep('ippAddScan', beginAddAfterScan);
    }

    if (sessionStorage.getItem('ippDeleteAllScanActive') === 'true') {
        ippScanStepInFlight['ippDeleteAllScan'] = false;
        scanAllPagesStep('ippDeleteAllScan', beginDeleteWithTargets);
    }

    if (ippObserver) {
        ippObserver.observe(document.forms['form1'] || document.body, { childList: true, subtree: true });
    }
}

function initDomWatcher() {
    const target = document.forms['form1'] || document.body;
    ippObserver = new MutationObserver(() => {
        clearTimeout(ippMutationDebounce);
        ippMutationDebounce = setTimeout(handleDomSettled, IPP_TIMING.mutationDebounceMs);
    });
    ippObserver.observe(target, { childList: true, subtree: true });
}

function finishDeleteAutomation() {
    clearDeleteQueueState();

    if (DOM.deleteStatusDiv) {
        DOM.deleteStatusDiv.innerText = 'Deletion Complete!';
        DOM.deleteStatusDiv.style.color = '#28a745';
    }
    if (DOM.deleteProgressBar) {
        DOM.deleteProgressBar.style.width = '100%';
    }
    injectDeleteCheckboxes();
    if (DOM.deleteStartBtn) {
        updateDeleteSelectionCount();
    }
}

// --- 10. Listeners & Initialization ---
chrome.runtime.onMessage.addListener((request) => {
    if (request.action === "toggleUI") togglePanelVisibility();
});

createUI();
initDomWatcher();

// Auto-resume Add queue
if (sessionStorage.getItem('ippQueue')) {
    let queue = JSON.parse(sessionStorage.getItem('ippQueue'));
    if (queue.length > 0) {
        AppState.isProcessing = true;
        setUIForProcessing();
        setTimeout(processNextItem, 1500); 
    }
}

// Auto-resume Update queue
if (sessionStorage.getItem('ippUpdateActive') === 'true') {
    switchTab('update');
    setUIForUpdateProcessing();
    setTimeout(runUpdateStep, 1500);
}

// Auto-resume Delete queue
if (sessionStorage.getItem('ippDeleteActive') === 'true') {
    switchTab('delete');
    setUIForDeleteProcessing();
    setTimeout(runDeleteStep, 1500);
}

// Auto-resume Add duplicate scan (walking every grid page)
if (sessionStorage.getItem('ippAddScanActive') === 'true') {
    setDataTableEditable(false);
    DOM.startBtn.disabled = true;
    DOM.statusDiv.innerText = "Scanning existing lessons...";
    DOM.statusDiv.style.color = "#325A7F";
    setTimeout(() => scanAllPagesStep('ippAddScan', beginAddAfterScan), 1500);
}

// Auto-resume Delete-all scan (walking every grid page)
if (sessionStorage.getItem('ippDeleteAllScanActive') === 'true') {
    switchTab('delete');
    setUIForDeleteScanning();
    setTimeout(() => scanAllPagesStep('ippDeleteAllScan', beginDeleteWithTargets), 1500);
}