// content.js

// --- 1. State Management ---
const AppState = {
    isPanelVisible: localStorage.getItem('ippUIVisible') !== 'false',
    isPanelActive: localStorage.getItem('ippUIActive') !== 'false',
    isProcessing: false,
    totalItems: 0
};

// Cache for DOM elements to avoid repeated lookups
const DOM = {};

// --- 2. CSS Injection ---
function injectCSS() {
    const style = document.createElement('style');
    style.textContent = `
        /* Panel Styles */
        #ippAutoPanel { position: fixed; bottom: 20px; right: 20px; background: #f8f9fa; border: 2px solid #325A7F; padding: 15px; z-index: 999999; box-shadow: 0px 4px 15px rgba(0,0,0,0.2); font-family: Arial, sans-serif; border-radius: 8px; transition: width 0.3s ease; }
        .ipp-header { display: flex; justify-content: space-between; align-items: center; transition: margin 0.3s ease; cursor: move; }
        .ipp-title { margin: 0; color: #325A7F; font-size: 16px; pointer-events: none; }
        .ipp-toggle-wrapper { display: flex; align-items: center; cursor: default; }
        .ipp-toggle-text { font-size: 12px; color: #888; font-weight: bold; }
        
        /* Toggle Switch */
        .ipp-switch { position: relative; display: inline-block; width: 36px; height: 20px; margin-left: 8px; }
        .ipp-switch input { opacity: 0; width: 0; height: 0; }
        .ipp-slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .3s; border-radius: 34px; }
        .ipp-slider:before { position: absolute; content: ""; height: 14px; width: 14px; left: 3px; bottom: 3px; background-color: white; transition: .3s; border-radius: 50%; box-shadow: 0 1px 3px rgba(0,0,0,0.3); }
        .ipp-switch input:checked + .ipp-slider { background-color: #325A7F; }
        .ipp-switch input:checked + .ipp-slider:before { transform: translateX(16px); }
        
        /* Tabs */
        .ipp-tabs { display: flex; border-bottom: 1px solid #ccc; margin-bottom: 10px; }
        .ipp-tab { flex: 1; padding: 6px 0; border: none; background: transparent; cursor: pointer; font-size: 12px; color: #555; text-align: center; transition: 0.2s; }
        .ipp-tab:hover { background: #e9ecef; }
        .ipp-tab.active { border-bottom: 2px solid #325A7F; font-weight: bold; color: #325A7F; }
        .ipp-badge { background: #dc3545; color: white; border-radius: 10px; padding: 2px 6px; font-size: 9px; margin-left: 4px; display: none; }
        
        /* Input & Preview Areas */
        .ipp-label { font-size: 11px; color: #555; margin: 0 0 8px 0; display: block; }
        .ipp-textarea { width: 100%; box-sizing: border-box; height: 100px; margin-bottom: 10px; font-family: monospace; white-space: pre; border-radius: 4px; border: 1px solid #ccc; padding: 5px; resize: vertical; }
        .ipp-scrollable { max-height: 120px; overflow-y: auto; border: 1px solid #ccc; border-radius: 4px; padding: 0; background: #fff; margin-bottom: 10px; }
        .ipp-preview-container { text-align: center; color: #888; font-size: 11px; padding: 10px; }
        
        /* Table */
        .ipp-table { width: 100%; border-collapse: collapse; font-size: 11px; margin: 0; }
        .ipp-table th, .ipp-table td { border-bottom: 1px solid #eee; border-right: 1px solid #eee; padding: 6px; text-align: left; }
        .ipp-table th { background-color: #f1f3f5; position: sticky; top: 0; box-shadow: 0 1px 0 #ccc; }
        .ipp-table tr:last-child td { border-bottom: none; }
        .ipp-table td:last-child, .ipp-table th:last-child { border-right: none; }
        
        /* Progress & Status */
        .ipp-progress-container { width: 100%; background-color: #e9ecef; border-radius: 4px; margin-bottom: 10px; overflow: hidden; display: none; }
        .ipp-progress-bar { height: 8px; background-color: #28a745; width: 0%; transition: width 0.3s; }
        .ipp-error-list { color: #dc3545; font-size: 11px; margin: 10px 0; padding-left: 20px; }
        .ipp-btn { width: 100%; padding: 8px; background: #325A7F; color: white; border: none; cursor: pointer; font-weight: bold; border-radius: 4px; transition: background 0.2s; opacity: 0.5; }
        .ipp-btn.danger { background: #dc3545; }
        .ipp-status { margin-top: 10px; font-size: 12px; font-weight: bold; color: #333; text-align: center; }
        .ipp-delete-summary { font-size: 12px; color: #555; margin-bottom: 10px; text-align: center; }

        /* Editable data table (combined paste + review) */
        .ipp-edit-table { width: 100%; table-layout: fixed; border-collapse: collapse; font-size: 11px; }
        .ipp-edit-table th, .ipp-edit-table td { border-bottom: 1px solid #eee; border-right: 1px solid #eee; padding: 0; text-align: left; }
        .ipp-edit-table th { background-color: #f1f3f5; padding: 6px; position: sticky; top: 0; box-shadow: 0 1px 0 #ccc; white-space: nowrap; }
        .ipp-edit-table tr:last-child td { border-bottom: none; }
        .ipp-edit-table th:nth-child(2), .ipp-edit-table td:nth-child(2) { width: 52px; }
        .ipp-edit-table th:nth-child(3), .ipp-edit-table td:nth-child(3) { width: 52px; }
        .ipp-edit-table th:nth-child(2), .ipp-edit-table th:nth-child(3) { text-align: center; }
        .ipp-edit-table td:nth-child(2) .ipp-cell, .ipp-edit-table td:nth-child(3) .ipp-cell { padding-left: 3px; padding-right: 3px; }
        .ipp-edit-table td:last-child, .ipp-edit-table th:last-child { border-right: none; width: 22px; text-align: center; }
        .ipp-cell { width: 100%; box-sizing: border-box; border: none; background: transparent; padding: 6px; font-size: 11px; font-family: inherit; }
        .ipp-cell:focus { outline: 2px solid #325A7F; outline-offset: -2px; background: #fff; }
        .ipp-cell:disabled { color: #888; background: #f1f3f5; }
        .ipp-cell-narrow { text-align: center; }
        .ipp-row-remove { border: none; background: transparent; color: #dc3545; cursor: pointer; font-size: 14px; line-height: 1; padding: 4px 6px; }
        .ipp-row-remove:hover { color: #a71d2a; }
        .ipp-row-remove:disabled { color: #ccc; cursor: not-allowed; }

        /* Injected grid checkboxes (on the live IPP admin page, not our panel) */
        .ipp-del-checkbox { width: 15px; height: 15px; cursor: pointer; }
        .ipp-del-th, .ipp-del-td { width: 24px; text-align: center; }
    `;
    document.head.appendChild(style);
}

// --- 3. UI Initialization ---
function createUI() {
    injectCSS();

    const panel = document.createElement('div');
    panel.id = 'ippAutoPanel'; 
    panel.style.display = AppState.isPanelVisible ? 'block' : 'none';
    panel.style.width = AppState.isPanelActive ? '30%' : '320px';

    panel.innerHTML = `
        <div id="ippHeader" class="ipp-header" style="margin-bottom: ${AppState.isPanelActive ? '10px' : '0'};">
            <h3 class="ipp-title">Magic IPP Automation</h3>
            <div class="ipp-toggle-wrapper">
                <span id="ippToggleText" class="ipp-toggle-text">${AppState.isPanelActive ? 'ON' : 'OFF'}</span>
                <label class="ipp-switch" title="Toggle Automation Panel">
                    <input type="checkbox" id="ippToggleBtn" ${AppState.isPanelActive ? 'checked' : ''}>
                    <span class="ipp-slider"></span>
                </label>
            </div>
        </div>
        
        <div id="ippBody" style="display: ${AppState.isPanelActive ? 'block' : 'none'};">
            <div class="ipp-tabs">
                <button id="ippTabData" class="ipp-tab active">1. Add Lessons</button>
                <button id="ippTabDelete" class="ipp-tab">2. Delete Lessons</button>
            </div>

            <div id="ippViewData" style="display: block; margin-bottom: 10px;">
                <p class="ipp-label">Paste data (Lesson &nbsp;|&nbsp; Seg &nbsp;|&nbsp; Mins) anywhere in the table below.</p>
                <div class="ipp-scrollable">
                    <div id="ippDataTableContainer"></div>
                </div>

			<button id="ippStartBtn" class="ipp-btn" disabled>Start Automation</button>
            <div id="ippStatus" class="ipp-status">Ready</div>
            </div>

            <div id="ippViewDelete" style="display: none; margin-bottom: 10px;">
                <p class="ipp-label">Check the lessons you want to remove directly in the grid on the page, then click below.</p>
                <div id="ippDeleteSummary" class="ipp-delete-summary">0 selected</div>
                <div id="ippDeleteProgressContainer" class="ipp-progress-container">
                    <div id="ippDeleteProgressBar" class="ipp-progress-bar"></div>
                </div>
                <button id="ippDeleteStartBtn" class="ipp-btn danger" disabled>Delete Selected</button>
                <div id="ippDeleteStatus" class="ipp-status">Ready</div>
            </div>
            
            <div id="ippProgressContainer" class="ipp-progress-container">
                <div id="ippProgressBar" class="ipp-progress-bar"></div>
            </div>

            
        </div>
    `;

    document.body.appendChild(panel);
    cacheDOM();
    bindEvents();
    makeDraggable(panel, DOM.header);
    renderDataTable();
}

function cacheDOM() {
    DOM.panel = document.getElementById('ippAutoPanel');
    DOM.header = document.getElementById('ippHeader');
    DOM.body = document.getElementById('ippBody');
    DOM.toggleBtn = document.getElementById('ippToggleBtn');
    DOM.toggleText = document.getElementById('ippToggleText');
    
    DOM.tabData = document.getElementById('ippTabData');
    DOM.tabDelete = document.getElementById('ippTabDelete');
    DOM.viewData = document.getElementById('ippViewData');
    DOM.viewDelete = document.getElementById('ippViewDelete');

    DOM.dataTableContainer = document.getElementById('ippDataTableContainer');
    
    DOM.progressContainer = document.getElementById('ippProgressContainer');
    DOM.progressBar = document.getElementById('ippProgressBar');
    DOM.startBtn = document.getElementById('ippStartBtn');
    DOM.statusDiv = document.getElementById('ippStatus');

    DOM.deleteSummary = document.getElementById('ippDeleteSummary');
    DOM.deleteProgressContainer = document.getElementById('ippDeleteProgressContainer');
    DOM.deleteProgressBar = document.getElementById('ippDeleteProgressBar');
    DOM.deleteStartBtn = document.getElementById('ippDeleteStartBtn');
    DOM.deleteStatusDiv = document.getElementById('ippDeleteStatus');
}

function bindEvents() {
    DOM.startBtn.addEventListener('click', toggleAutomation);
    DOM.toggleBtn.addEventListener('change', handlePanelToggle);

    DOM.tabData.addEventListener('click', () => switchTab('data'));
    DOM.tabDelete.addEventListener('click', () => switchTab('delete'));

    DOM.deleteStartBtn.addEventListener('click', startDeleteAutomation);
}

// --- 4. UI Interactions & Draggable Logic ---
function switchTab(tabName) {
    DOM.tabData.classList.toggle('active', tabName === 'data');
    DOM.tabDelete.classList.toggle('active', tabName === 'delete');

    DOM.viewData.style.display = tabName === 'data' ? 'block' : 'none';
    DOM.viewDelete.style.display = tabName === 'delete' ? 'block' : 'none';

    // The Add-flow progress/status live outside the tab views, so only show them
    // for the data tab; the delete tab has its own progress/status.
    DOM.progressContainer.style.display = (tabName !== 'delete' && AppState.isProcessing) ? 'block' : 'none';
    DOM.statusDiv.style.display = tabName === 'delete' ? 'none' : 'block';

    // Only show the grid checkboxes while the user is actually on the Delete
    // tab, so the grid looks/behaves normally the rest of the time.
    ippDeleteTabActive = (tabName === 'delete');
    if (ippDeleteTabActive) {
        injectDeleteCheckboxes();
    } else {
        removeDeleteCheckboxes();
    }
}


function handlePanelToggle(e) {
    const isChecked = e.target.checked;
    
    DOM.panel.style.width = isChecked ? '30%' : '320px';
    DOM.body.style.display = isChecked ? 'block' : 'none';
    DOM.header.style.marginBottom = isChecked ? '10px' : '0';
    DOM.toggleText.innerText = isChecked ? 'ON' : 'OFF';
    
    //Reset position to default when toggled OFF
    if (!isChecked) {
        DOM.panel.style.top = '';
        DOM.panel.style.left = '';
        DOM.panel.style.bottom = ''; // Reverts to CSS default (20px)
        DOM.panel.style.right = '';  // Reverts to CSS default (20px)
    }
    
    AppState.isPanelActive = isChecked;
    localStorage.setItem('ippUIActive', isChecked);
}

function togglePanelVisibility() {
    if (!DOM.panel) return;
    const isHidden = DOM.panel.style.display === 'none';
    DOM.panel.style.display = isHidden ? 'block' : 'none';
    AppState.isPanelVisible = isHidden;
    localStorage.setItem('ippUIVisible', isHidden);
}

function makeDraggable(element, handle) {
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.onmousedown = dragMouseDown;

    function dragMouseDown(e) {
        if (e.target.closest('.ipp-switch')) return; 
        e.preventDefault();
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
        e.preventDefault();
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        
        element.style.top = (element.offsetTop - pos2) + "px";
        element.style.left = (element.offsetLeft - pos1) + "px";
        element.style.bottom = "auto"; 
        element.style.right = "auto"; 
    }

    function closeDragElement() {
        document.onmouseup = null;
        document.onmousemove = null;
    }
}

// --- 5. Editable Data Table (combined paste + review) ---
let ippRows = [];
let ippRowIdCounter = 0;

function createEmptyRow() {
    return { id: ippRowIdCounter++, lesson: '', segment: '', minutes: '' };
}

function escapeAttr(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

function getParsedData() {
    const dataQueue = ippRows
        .filter(row => row.lesson.trim() !== '')
        .map(row => ({
            lesson: row.lesson.trim(),
            segment: row.segment.trim(),
            minutes: row.minutes.trim()
        }));
    return { dataQueue };
}

function renderDataTable() {
    if (!DOM.dataTableContainer) return;

    if (ippRows.length === 0) {
        ippRows.push(createEmptyRow());
    }

    let html = `<table class="ipp-edit-table"><thead><tr><th>Lesson</th><th>Seg</th><th>Mins</th><th></th></tr></thead><tbody>`;
    ippRows.forEach(row => {
        html += `
            <tr data-row-id="${row.id}">
                <td><input type="text" class="ipp-cell" data-field="lesson" value="${escapeAttr(row.lesson)}"></td>
                <td><input type="text" class="ipp-cell ipp-cell-narrow" data-field="segment" value="${escapeAttr(row.segment)}"></td>
                <td><input type="text" class="ipp-cell ipp-cell-narrow" data-field="minutes" value="${escapeAttr(row.minutes)}"></td>
                <td><button type="button" class="ipp-row-remove" title="Remove row">&times;</button></td>
            </tr>`;
    });
    html += `</tbody></table>`;
    DOM.dataTableContainer.innerHTML = html;

    DOM.dataTableContainer.querySelectorAll('.ipp-cell').forEach(input => {
        input.addEventListener('input', handleCellInput);
        input.addEventListener('paste', handleCellPaste);
    });
    DOM.dataTableContainer.querySelectorAll('.ipp-row-remove').forEach(btn => {
        btn.addEventListener('click', handleRemoveRow);
    });

    updateStartButtonState();
}

function findRow(rowEl) {
    const id = Number(rowEl.dataset.rowId);
    return ippRows.find(r => r.id === id);
}

function handleCellInput(e) {
    const row = findRow(e.target.closest('tr'));
    if (!row) return;
    row[e.target.dataset.field] = e.target.value;
    updateStartButtonState();
}

function handleRemoveRow(e) {
    const rowEl = e.target.closest('tr');
    const id = Number(rowEl.dataset.rowId);
    ippRows = ippRows.filter(r => r.id !== id);
    renderDataTable();
}

// Segment is always "1" or "2". If a pasted row has something else in the
// segment slot but a "1"/"2" in the minutes slot, the source data was almost
// certainly Lesson | Minutes | Segment instead of Lesson | Segment | Minutes
// -- swap them back so the automation doesn't submit bad data silently.
function normalizeSegmentMinutesOrder(row) {
    const seg = row.segment.trim();
    const min = row.minutes.trim();
    const segLooksValid = seg === '1' || seg === '2';
    const minLooksLikeSegment = min === '1' || min === '2';

    if (!segLooksValid && minLooksLikeSegment) {
        row.segment = min;
        row.minutes = seg;
    }
}

// Lets the user paste a block copied from Excel/Sheets straight into the
// table -- starting at whichever cell they paste into -- instead of only
// being able to fill one input at a time. Multi-line/tab-separated pastes
// fill across columns and down new rows (adding rows as needed); a plain
// single value paste is left to the browser's normal behavior.
function handleCellPaste(e) {
    const text = (e.clipboardData || window.clipboardData).getData('text');
    if (!text.includes('\t') && !text.includes('\n')) {
        return; // Simple single-value paste; let the browser handle it normally.
    }
    e.preventDefault();

    const targetInput = e.target;
    const targetRow = targetInput.closest('tr');
    const startRowIndex = ippRows.findIndex(r => r.id === Number(targetRow.dataset.rowId));
    const fieldOrder = ['lesson', 'segment', 'minutes'];
    const startFieldIndex = fieldOrder.indexOf(targetInput.dataset.field);

    const lines = text.split(/\r\n|\n|\r/).filter(line => line.trim() !== '');

    lines.forEach((line, lineOffset) => {
        const cols = line.split('\t');
        const rowIndex = startRowIndex + lineOffset;

        while (rowIndex >= ippRows.length) {
            ippRows.push(createEmptyRow());
        }

        let touchedSegment = false;
        let touchedMinutes = false;

        cols.forEach((val, colOffset) => {
            const fieldIndex = startFieldIndex + colOffset;
            if (fieldIndex < fieldOrder.length) {
                const field = fieldOrder[fieldIndex];
                ippRows[rowIndex][field] = val.trim();
                if (field === 'segment') touchedSegment = true;
                if (field === 'minutes') touchedMinutes = true;
            }
        });

        // Only worth checking for a swap if this paste actually supplied
        // both columns -- a partial paste into just one field shouldn't be
        // second-guessed.
        if (touchedSegment && touchedMinutes) {
            normalizeSegmentMinutesOrder(ippRows[rowIndex]);
        }
    });

    renderDataTable();
}

function updateStartButtonState() {
    const { dataQueue } = getParsedData();
    DOM.startBtn.disabled = dataQueue.length === 0;
    DOM.startBtn.style.opacity = dataQueue.length === 0 ? '0.5' : '1';
    DOM.startBtn.style.cursor = dataQueue.length === 0 ? 'not-allowed' : 'pointer';
}

function setDataTableEditable(enabled) {
    if (!DOM.dataTableContainer) return;
    DOM.dataTableContainer.querySelectorAll('.ipp-cell, .ipp-row-remove').forEach(el => {
        el.disabled = !enabled;
    });
}


// --- 6. Core Automation Logic (Add) ---

// True right after we've auto-clicked the "Add" button and are waiting for
// its partial postback to finish enabling the entry form. Prevents us from
// clicking it again every second while that's in flight; the safety-net
// timeout below clears it if the postback takes longer than expected or
// never lands, so processNextItem's polling loop can just try again.
let ippAddButtonClicked = false;

function toggleAutomation() {
    if (AppState.isProcessing) {
        stopAutomation();
        return;
    }

    const { dataQueue } = getParsedData();

    if (dataQueue.length > 0) {
        AppState.isProcessing = true;
        AppState.totalItems = dataQueue.length;
        
        sessionStorage.setItem('ippQueue', JSON.stringify(dataQueue));
        sessionStorage.setItem('ippTotalItems', AppState.totalItems);
        
        setUIForProcessing();
        processNextItem();
    } else {
        DOM.statusDiv.innerText = "No valid data found!";
        DOM.statusDiv.style.color = "red";
    }
}

function stopAutomation() {
    AppState.isProcessing = false;
    ippAddButtonClicked = false;
    DOM.startBtn.innerText = "Start Automation";
    DOM.startBtn.style.background = "#325A7F";
    DOM.statusDiv.innerText = "Automation Stopped.";
    DOM.statusDiv.style.color = "#dc3545";
    setDataTableEditable(true);
    sessionStorage.removeItem('ippQueue');
}

function setUIForProcessing() {
    DOM.startBtn.innerText = "Stop / Cancel";
    DOM.startBtn.style.background = "#dc3545";
    setDataTableEditable(false);
    
    DOM.progressContainer.style.display = 'block';
    DOM.progressBar.style.width = '0%';
    
    switchTab('data');
}

function processNextItem() {
    if (!AppState.isProcessing) return; 

    let queue = JSON.parse(sessionStorage.getItem('ippQueue') || '[]');
    let initialTotal = parseInt(sessionStorage.getItem('ippTotalItems') || queue.length);

    if (queue.length === 0) {
        finishAutomation();
        return;
    }

    const completed = initialTotal - queue.length;
    DOM.progressBar.style.width = `${Math.round((completed / initialTotal) * 100)}%`;

    DOM.statusDiv.innerText = `Processing... (${queue.length} items left)`;
    DOM.statusDiv.style.color = "#325A7F";
    
    const currentItem = queue[0];
    const targetFields = {
        desc: document.getElementById('ctl04_BaseSelectionDetail1_ctl01_BaseTextBoxDescription'),
        min: document.getElementById('ctl04_BaseSelectionDetail1_ctl01_BaseTextBoxMinutes'),
        seg: document.getElementById('ctl04_BaseSelectionDetail1_ctl01_BaseTextBoxSegment'),
        btn: document.getElementById('ctl04_BaseSelectionDetail1_BaseButtonSaveAddNew')
    };

    if (targetFields.desc && !targetFields.desc.disabled && targetFields.btn && !targetFields.btn.disabled) {
        ippAddButtonClicked = false;
        targetFields.desc.value = currentItem.lesson;
        targetFields.min.value = currentItem.minutes;
        targetFields.seg.value = currentItem.segment;

        queue.shift(); 
        sessionStorage.setItem('ippQueue', JSON.stringify(queue));

        targetFields.btn.click();
        waitForReset();
    } else {
        // The entry form (Lesson/Minutes/Segment) starts out disabled until
        // "Add" is pressed -- e.g. whenever the course has no lessons yet,
        // the grid shows "There are no items for this filter condition." and
        // only BaseButtonAdd is enabled. Click it automatically so the user
        // doesn't have to, but only once per attempt: clicking repeatedly
        // while its partial postback is still in flight could double-fire it.
        const addBtn = document.getElementById('ctl04_BaseSelectionDetail1_BaseButtonAdd');
        if (addBtn && !addBtn.disabled && !ippAddButtonClicked) {
            ippAddButtonClicked = true;
            DOM.statusDiv.innerText = "Opening the Add form...";
            DOM.statusDiv.style.color = "#325A7F";
            addBtn.click();
            // Safety net: if the form doesn't end up enabled for some reason,
            // allow another attempt rather than getting stuck forever.
            setTimeout(() => { ippAddButtonClicked = false; }, 5000);
        } else if (!addBtn) {
            DOM.statusDiv.innerText = "Select 'Add' to begin automation...";
            DOM.statusDiv.style.color = "#c71585";
        }
        setTimeout(processNextItem, 1000); 
    }
}

function finishAutomation() {
    DOM.statusDiv.innerText = "Automation Complete!";
    DOM.statusDiv.style.color = "#28a745";
    ippRows = [];
    setDataTableEditable(true);
    
    DOM.startBtn.innerText = "Start Automation";
    DOM.startBtn.style.background = "#325A7F";
    AppState.isProcessing = false;
    ippAddButtonClicked = false;
    
    sessionStorage.removeItem('ippQueue');
    sessionStorage.removeItem('ippTotalItems');
    DOM.progressBar.style.width = '100%';
    renderDataTable();
}

function waitForReset() {
    if (!AppState.isProcessing) return;
    
    setTimeout(() => {
        const descField = document.getElementById('ctl04_BaseSelectionDetail1_ctl01_BaseTextBoxDescription');
        if (descField && !descField.disabled && descField.value === '') {
            processNextItem();
        } else {
            waitForReset();
        }
    }, 500);
}

// --- 7. Grid Checkbox Injection & Delete Automation ---

// True only while the user is on the Delete tab; controls whether the grid
// checkbox column should exist at all.
let ippDeleteTabActive = false;

// Which lessons are currently checked for deletion, tracked independently of
// the checkbox DOM elements themselves. This is what makes selections survive
// a grid refresh (e.g. an accidental row click, or our own automation
// re-rendering the grid): the checkboxes get destroyed and recreated on every
// AJAX swap, but this set does not, so we can restore the checkmarks from it.
let ippSelectedForDelete = new Set();

function keyForItem(item) {
    return `${item.lesson}||${item.segment}||${item.minutes}`;
}

// Reads the live grid on the page (lesson/segment/minutes per row) so we can
// match queued delete targets by their visible text, since the row's internal
// ASP.NET control IDs (ctl02, ctl03, ...) get renumbered every time the grid
// re-renders after a postback.
function getGridRows() {
    const table = document.getElementById('ctl04_BaseSelectionDetail1_ctl02_GridViewCourseModules');
    if (!table) return [];

    const rows = Array.from(table.querySelectorAll('tr')).filter(r => r.hasAttribute('onclick'));

    return rows.map(row => {
        const cells = row.querySelectorAll('td');
        // Cell 0 is the injected checkbox cell once injectDeleteCheckboxes has run,
        // so detect that and offset accordingly.
        const offset = row.querySelector('.ipp-del-td') ? 1 : 0;
        return {
            row,
            lesson: cells[offset] ? cells[offset].textContent.trim() : '',
            segment: cells[offset + 1] ? cells[offset + 1].textContent.trim() : '',
            minutes: cells[offset + 2] ? cells[offset + 2].textContent.trim() : ''
        };
    });
}

// Adds a checkbox column to the real grid on the page (not our panel) so the
// user can tick lessons for deletion directly where they already see them.
// Only does anything while the Delete tab is active, and restores checked
// state from ippSelectedForDelete so a grid refresh doesn't lose selections.
function injectDeleteCheckboxes() {
    if (!ippDeleteTabActive) return;

    const table = document.getElementById('ctl04_BaseSelectionDetail1_ctl02_GridViewCourseModules');
    if (!table || table.dataset.ippCheckboxesInjected) return;
    table.dataset.ippCheckboxesInjected = 'true';

    const headerRow = table.querySelector('tr.GridView_HeaderStyleClass');
    if (headerRow) {
        const th = document.createElement('th');
        th.className = 'ipp-del-th';
        th.scope = 'col';

        const selectAllCb = document.createElement('input');
        selectAllCb.type = 'checkbox';
        selectAllCb.className = 'ipp-del-checkbox ipp-del-select-all';
        selectAllCb.title = 'Select/deselect all';
        selectAllCb.addEventListener('click', (e) => e.stopPropagation());
        selectAllCb.addEventListener('change', (e) => {
            const shouldSelect = e.target.checked;
            getGridRows().forEach(item => {
                const key = keyForItem(item);
                if (shouldSelect) {
                    ippSelectedForDelete.add(key);
                } else {
                    ippSelectedForDelete.delete(key);
                }
                const rowCb = item.row.querySelector('.ipp-del-checkbox:not(.ipp-del-select-all)');
                if (rowCb) rowCb.checked = shouldSelect;
            });
            updateDeleteSelectionCount();
        });

        th.appendChild(selectAllCb);
        headerRow.insertBefore(th, headerRow.firstChild);
    }

    getGridRows().forEach(item => {
        const td = document.createElement('td');
        td.className = 'ipp-del-td';

        const cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.className = 'ipp-del-checkbox';
        cb.checked = ippSelectedForDelete.has(keyForItem(item));
        // Stop the click from bubbling to the row's own onclick (row selection).
        cb.addEventListener('click', (e) => e.stopPropagation());
        cb.addEventListener('change', (e) => {
            const key = keyForItem(item);
            if (e.target.checked) {
                ippSelectedForDelete.add(key);
            } else {
                ippSelectedForDelete.delete(key);
            }
            updateDeleteSelectionCount();
        });

        td.appendChild(cb);
        item.row.insertBefore(td, item.row.firstChild);
    });

    updateDeleteSelectionCount();
}

// Keeps the header "select all" checkbox in sync: checked when every row is
// selected, unchecked when none are, and indeterminate (a dash) when it's a
// mix -- standard "select all" behavior.
function updateSelectAllCheckboxState() {
    const selectAllCb = document.querySelector('.ipp-del-select-all');
    if (!selectAllCb) return;

    const rows = getGridRows();
    if (rows.length === 0) {
        selectAllCb.checked = false;
        selectAllCb.indeterminate = false;
        return;
    }

    const selectedCount = rows.filter(item => ippSelectedForDelete.has(keyForItem(item))).length;
    selectAllCb.checked = selectedCount === rows.length;
    selectAllCb.indeterminate = selectedCount > 0 && selectedCount < rows.length;
}

// Strips the checkbox column back out when the user leaves the Delete tab,
// so the grid looks and behaves like normal everywhere else.
function removeDeleteCheckboxes() {
    const table = document.getElementById('ctl04_BaseSelectionDetail1_ctl02_GridViewCourseModules');
    if (!table) return;
    table.querySelectorAll('.ipp-del-th, .ipp-del-td').forEach(el => el.remove());
    delete table.dataset.ippCheckboxesInjected;
}

function updateDeleteSelectionCount() {
    const count = ippSelectedForDelete.size;
    if (DOM.deleteSummary) {
        DOM.deleteSummary.textContent = `${count} selected`;
    }
    if (DOM.deleteStartBtn) {
        DOM.deleteStartBtn.disabled = count === 0;
        DOM.deleteStartBtn.style.opacity = count === 0 ? '0.5' : '1';
        DOM.deleteStartBtn.style.cursor = count === 0 ? 'not-allowed' : 'pointer';
    }
    updateSelectAllCheckboxState();
}



function startDeleteAutomation() {
    const targets = getGridRows()
        .filter(item => ippSelectedForDelete.has(keyForItem(item)))
        .map(item => ({ lesson: item.lesson, segment: item.segment, minutes: item.minutes }));

    if (targets.length === 0) return;

    // These are now queued for deletion, so they're no longer "pending selection".
    targets.forEach(t => ippSelectedForDelete.delete(keyForItem(t)));
    updateDeleteSelectionCount();

    sessionStorage.setItem('ippDeleteQueue', JSON.stringify(targets));
    sessionStorage.setItem('ippDeleteTotal', targets.length);
    sessionStorage.setItem('ippDeleteStage', 'select');
    sessionStorage.setItem('ippDeleteActive', 'true');

    setUIForDeleteProcessing();
    runDeleteStep();
}


function setUIForDeleteProcessing() {
    DOM.deleteStartBtn.disabled = true;
    DOM.deleteProgressContainer.style.display = 'block';
    DOM.deleteProgressBar.style.width = '0%';
    DOM.deleteStatusDiv.innerText = 'Deleting...';
    DOM.deleteStatusDiv.style.color = '#325A7F';
}

// Runs one step of the delete state machine. Because selecting a row and
// clicking Delete are each full ASP.NET postbacks, this function only ever
// performs ONE action then returns — the page reloads, the content script
// re-runs, and the "resume on load" logic at the bottom of this file calls
// this function again to pick up where it left off. State lives in
// sessionStorage so it survives the reload.
// Guards against re-entering runDeleteStep while we're already waiting on
// an in-flight click (the DOM watcher can fire more than once per update).
let ippDeleteStepInFlight = false;

function runDeleteStep() {
    if (sessionStorage.getItem('ippDeleteActive') !== 'true') return;
    if (ippDeleteStepInFlight) return;

    const queue = JSON.parse(sessionStorage.getItem('ippDeleteQueue') || '[]');
    const total = parseInt(sessionStorage.getItem('ippDeleteTotal') || queue.length);
    const stage = sessionStorage.getItem('ippDeleteStage') || 'select';

    if (DOM.deleteStatusDiv) {
        const completed = total - queue.length;
        DOM.deleteProgressBar.style.width = `${Math.round((completed / total) * 100)}%`;
        DOM.deleteStatusDiv.innerText = queue.length > 0 ? `Deleting... (${queue.length} left)` : 'Deleting...';
    }

    if (queue.length === 0) {
        finishDeleteAutomation();
        return;
    }

    const target = queue[0];
    const rows = getGridRows();
    const match = rows.find(r => r.lesson === target.lesson && r.segment === target.segment && r.minutes === target.minutes);

    if (stage === 'select') {
        if (!match) {
            // The grid may not have finished re-rendering yet, or the row is genuinely gone. Retry briefly.
            setTimeout(runDeleteStep, 400);
            return;
        }
        // Mark that once the resulting AJAX update settles, we should confirm+delete.
        // The DOM watcher (MutationObserver) is what calls runDeleteStep again after
        // the partial postback completes -- this page never actually reloads.
        ippDeleteStepInFlight = true;
        sessionStorage.setItem('ippDeleteStage', 'confirmDelete');
        match.row.click();
        // Safety net in case the mutation observer misses this update for any reason.
        setTimeout(() => { ippDeleteStepInFlight = false; }, 4000);
        return;
    }

    if (stage === 'confirmDelete') {
        const deleteBtn = document.getElementById('ctl04_BaseSelectionDetail1_BaseButtonDelete');
        const descField = document.getElementById('ctl04_BaseSelectionDetail1_ctl01_BaseTextBoxDescription');

        if (!deleteBtn || !descField) {
            setTimeout(runDeleteStep, 400);
            return;
        }

        // Safety check: only delete if the detail panel actually loaded OUR target item.
        if (descField.value.trim() !== target.lesson) {
            setTimeout(runDeleteStep, 400);
            return;
        }

        // The "Delete This Item?" confirm() dialog is auto-accepted by
        // confirm-override.js, a separate content script declared with
        // "world": "MAIN" in manifest.json. That runs in the page's real JS
        // context (unlike this file), so it can genuinely override the
        // page's own window.confirm -- and it's an extension resource, not
        // page-injected inline code, so the site's CSP doesn't block it.
        queue.shift();
        sessionStorage.setItem('ippDeleteQueue', JSON.stringify(queue));
        sessionStorage.setItem('ippDeleteStage', 'select');

        ippDeleteStepInFlight = true;
        deleteBtn.click(); // fires confirm() (auto-true from main world), then an async partial postback removes the row

        setTimeout(() => { ippDeleteStepInFlight = false; }, 4000);
        return;
    }
}

// --- 7b. DOM watcher ---
// This page updates the grid and detail panel via async partial postbacks
// (an ASP.NET UpdatePanel), not full navigations, so the content script never
// gets torn down and re-run. That also means our injected checkboxes get
// wiped out any time the grid re-renders -- from automation OR a manual
// click. A MutationObserver lets us react to those swaps directly instead of
// (wrongly) waiting for a page load that will never come.
let ippObserver = null;
let ippMutationDebounce = null;

function handleDomSettled() {
    if (ippObserver) ippObserver.disconnect();

    injectDeleteCheckboxes();
    updateDeleteSelectionCount();

    if (sessionStorage.getItem('ippDeleteActive') === 'true') {
        ippDeleteStepInFlight = false;
        runDeleteStep();
    }

    if (ippObserver) {
        ippObserver.observe(document.forms['form1'] || document.body, { childList: true, subtree: true });
    }
}

function initDomWatcher() {
    const target = document.forms['form1'] || document.body;
    ippObserver = new MutationObserver(() => {
        clearTimeout(ippMutationDebounce);
        // Wait for a short quiet period so we act once the AJAX swap has
        // fully finished, not mid-update.
        ippMutationDebounce = setTimeout(handleDomSettled, 350);
    });
    ippObserver.observe(target, { childList: true, subtree: true });
}

function finishDeleteAutomation() {
    sessionStorage.removeItem('ippDeleteQueue');
    sessionStorage.removeItem('ippDeleteTotal');
    sessionStorage.removeItem('ippDeleteStage');
    sessionStorage.removeItem('ippDeleteActive');

    if (DOM.deleteStatusDiv) {
        DOM.deleteStatusDiv.innerText = 'Deletion Complete!';
        DOM.deleteStatusDiv.style.color = '#28a745';
    }
    if (DOM.deleteProgressBar) {
        DOM.deleteProgressBar.style.width = '100%';
    }
    if (DOM.deleteStartBtn) {
        updateDeleteSelectionCount();
    }
}

// --- 8. Listeners & Initialization ---
chrome.runtime.onMessage.addListener((request) => {
    if (request.action === "toggleUI") togglePanelVisibility();
});

createUI();
initDomWatcher();
// Note: the "Delete This Item?" confirm() override lives in confirm-override.js,
// a separate MAIN-world content script declared in manifest.json -- it runs
// on its own, no call needed from here.

// Auto-resume if an Add queue exists (covers the rare case of a true page reload,
// e.g. a manual refresh mid-run; normally the DOM watcher handles continuation)
if (sessionStorage.getItem('ippQueue')) {
    let queue = JSON.parse(sessionStorage.getItem('ippQueue'));
    if (queue.length > 0) {
        AppState.isProcessing = true;
        setUIForProcessing();
        setTimeout(processNextItem, 1500); 
    }
}

// Auto-resume if a Delete queue exists (same reasoning as above)
if (sessionStorage.getItem('ippDeleteActive') === 'true') {
    switchTab('delete');
    setUIForDeleteProcessing();
    setTimeout(runDeleteStep, 1500);
}
