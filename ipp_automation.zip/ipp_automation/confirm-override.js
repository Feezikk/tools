// confirm-override.js
//
// This file is loaded as a content script but declared with "world": "MAIN"
// in manifest.json, so it runs directly in the page's own JavaScript context
// -- unlike content.js, which runs in an isolated world that the page's own
// inline onclick="return confirm(...)" handlers never see.
//
// Injecting a <script> tag with inline code (the previous approach) gets
// blocked by this site's Content-Security-Policy (script-src requires a
// nonce/hash for inline script). A manifest-declared MAIN-world content
// script is an extension resource, not page-injected inline code, so CSP's
// script-src restriction doesn't apply to it.
//
// sessionStorage is shared between isolated and main worlds (it's browser
// storage tied to the page's origin, not a JS-world-scoped variable), so
// this can safely check the same ippDeleteActive flag that content.js sets
// while a bulk delete is running, and only auto-accept in that case. A
// manual, one-off delete elsewhere still shows the real confirmation prompt.
(function () {
    const originalConfirm = window.confirm;
    window.confirm = function (message) {
        if (sessionStorage.getItem('ippDeleteActive') === 'true') {
            return true;
        }
        return originalConfirm.call(window, message);
    };
})();
