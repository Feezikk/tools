// postback-bridge.js
//
// Runs in the page's MAIN world (see manifest.json), same reasoning as
// confirm-override.js: it needs direct access to the page's own JS globals,
// which content.js (isolated world) can't see.
//
// The grid's pager links are <a href="javascript:__doPostBack('target','arg')">.
// Navigating that javascript: URL (e.g. via link.click() from content.js) is
// blocked by this site's Content-Security-Policy -- script-src has no
// 'unsafe-inline', and that covers javascript: navigations specifically.
// Calling __doPostBack directly as a function is a normal function call, not
// a javascript: navigation, so it isn't subject to that restriction -- but
// __doPostBack only exists as a global in the page's MAIN world.
//
// content.js parses the target/argument out of a pager link's href itself
// (just reading the attribute, no execution involved) and dispatches an
// 'ippDoPostBack' CustomEvent on window with them. Events dispatched on
// window/document cross the isolated/main world boundary fine even though
// JS variables don't, so we just listen for it here and make the real call.
window.addEventListener('ippDoPostBack', function (e) {
    const detail = (e && e.detail) || {};
    const target = detail.target;
    const argument = detail.argument || '';

    if (target && typeof __doPostBack === 'function') {
        __doPostBack(target, argument);
    }
});
